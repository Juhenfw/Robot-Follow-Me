import serial
import math
import time

port = "/dev/ttyUSB2"
baudrate = 115200
timeout = 1

L = 165  # Panjang robot
W = 50  # Lebar robot

# Definisi posisi anchor
anchors = {
    "A0": (-L / 2, W / 2),  # Depan kiri
    "A1": (-L / 2, -W / 2),  # Depan kanan
    "A2": (L / 2, 0),  # Belakang tengah
}

# Fungsi untuk menghitung posisi tag berdasarkan jarak
def calculate_tag_position(distances):
    weights = []
    x_tag, y_tag = 0, 0
    for i, (anchor, dist) in enumerate(zip(anchors.values(), distances)):
        x, y = anchor
        weight = 1 / dist if dist > 0 else 0
        weights.append(weight)
        x_tag += x * weight
        y_tag += y * weight
    total_weight = sum(weights)
    if total_weight > 0:
        x_tag /= total_weight
        y_tag /= total_weight
    return x_tag, y_tag

# Fungsi untuk menghitung jarak dan sudut dari tag
def calculate_distance_and_angle(x_tag, y_tag):
    distance = math.sqrt(x_tag**2 + y_tag**2)
    angle = math.degrees(math.atan2(y_tag, x_tag))
    return distance, angle

# Fungsi untuk memilih sensor mana yang akan digunakan
def select_sensor(sensor_name):
    if sensor_name not in anchors:
        raise ValueError("Sensor tidak valid. Pilih dari A0, A1, atau A2.")
    return anchors[sensor_name]

# Fungsi untuk cek status serial dan koneksi
def check_serial_connection(ser):
    if not ser.is_open:
        print("Error: Koneksi serial gagal. Periksa kabel dan port.")
        return False
    return True

try:
    # Membuka koneksi serial
    ser = serial.Serial(port, baudrate, timeout=timeout)
    
    # Menunggu beberapa detik untuk memastikan sensor siap
    print("Menunggu perangkat UWB untuk merespon...")
    time.sleep(2)

    # Mengecek apakah koneksi serial berhasil
    if not check_serial_connection(ser):
        raise serial.SerialException("Koneksi serial tidak berhasil. Program dihentikan.")
    
    while True:
        if ser.in_waiting > 0:
            data = ser.readline().decode("utf-8").strip()
            
            if data.startswith("$KT0"):
                try:
                    parts = data.split(",")
                    if len(parts) >= 4:
                        raw_values = parts[1:4]
                        processed_values = []
                        for value in raw_values:
                            if value.lower() == "null":
                                processed_values.append(0.0)
                            else:
                                processed_values.append(float(value))
                        
                        # Pilih sensor yang akan digunakan, misalnya sensor A0
                        selected_sensor = "A0"  # Bisa diganti A1 atau A2 untuk memilih sensor lainnya
                        sensor_position = select_sensor(selected_sensor)
                        print(f"Sensor {selected_sensor} dipilih dengan posisi {sensor_position}")

                        # Gunakan nilai dari sensor yang dipilih
                        A0, A1, A2 = [val * 100 for val in processed_values]
                        distances = [A0 if selected_sensor == "A0" else 0, 
                                     A1 if selected_sensor == "A1" else 0, 
                                     A2 if selected_sensor == "A2" else 0]
                        
                        x_tag, y_tag = calculate_tag_position(distances)
                        distance, angle = calculate_distance_and_angle(x_tag, y_tag)
                        print(
                            f"A0 = {A0:.2f} cm | A1 = {A1:.2f} cm | A2 = {A2:.2f} cm | "
                            f"T0 to Robot = {distance:.2f} cm | Sudut = {angle:.2f}°"
                        )
                    else:
                        print("Error: Data tidak lengkap.")
                except ValueError as e:
                    print(f"Error processing data: {e}")
            else:
                print("Data yang diterima tidak sesuai format yang diharapkan.")
        else:
            print("Menunggu data dari sensor...")

except serial.SerialException as e:
    print(f"Error: {e}")
except Exception as e:
    print(f"Terjadi kesalahan: {e}")
finally:
    if "ser" in locals() and ser.is_open:
        ser.close()
        print("Koneksi serial ditutup.")
