import serial
import time
import math

# Konfigurasi RS485 untuk motor DDSM115
PORT_RS485 = "/dev/ttyUSB0"  # Sesuaikan dengan port USB to RS485
BAUDRATE = 115200
TIMEOUT = 1

# Fungsi untuk mengirim perintah ke motor melalui RS485
def send_motor_command(id_motor, speed):
    """
    Mengirim perintah ke DDSM115 melalui RS485
    :param id_motor: ID motor (1 = Kiri, 2 = Kanan)
    :param speed: Kecepatan (-100 hingga 100, negatif = mundur)
    """
    if speed > 100: speed = 100
    if speed < -100: speed = -100

    # Format data sesuai protokol DDSM115
    direction = 0x01 if speed >= 0 else 0x02  # 0x01 = Maju, 0x02 = Mundur
    speed_value = abs(speed)  # Kecepatan absolut

    # Format perintah ke DDSM115 (sesuai manual)
    command = bytearray([0xAA, id_motor, direction, speed_value, 0x55])
    ser.write(command)
    time.sleep(0.05)  # Delay untuk komunikasi

# Fungsi untuk menghitung jarak dan sudut antara robot dan A2
def calculate_distance_and_angle(x_tag, y_tag):
    distance = math.sqrt(x_tag*2 + y_tag*2)
    angle = math.degrees(math.atan2(y_tag, x_tag))
    return distance, angle

# Fungsi untuk mengontrol motor berdasarkan posisi A2
def move_robot(distance, angle):
    speed = min(distance * 0.5, 100)  # Maksimal 100% PWM
    if angle > 10:  # Belok ke kanan
        send_motor_command(1, speed)  # Motor kiri lebih cepat
        send_motor_command(2, speed / 2)  # Motor kanan lebih lambat
    elif angle < -10:  # Belok ke kiri
        send_motor_command(1, speed / 2)  # Motor kiri lebih lambat
        send_motor_command(2, speed)  # Motor kanan lebih cepat
    else:  # Lurus
        send_motor_command(1, speed)
        send_motor_command(2, speed)
    
    if distance < 10:  # Jika sudah dekat, berhenti
        send_motor_command(1, 0)
        send_motor_command(2, 0)

try:
    ser = serial.Serial(PORT_RS485, BAUDRATE, timeout=TIMEOUT)
    print("Connected to RS485 Motor Controller")

    # Contoh: Gerakkan motor dengan kecepatan 50% maju
    send_motor_command(1, 50)
    send_motor_command(2, 50)

    time.sleep(3)  # Jalan selama 3 detik

    # Berhenti
    send_motor_command(1, 0)
    send_motor_command(2, 0)

except serial.SerialException as e:
    print(f"Error: {e}")

finally:
    if "ser" in locals() and ser.is_open:
        ser.close()
    print("Program stopped.")