
#!/usr/bin/env python3

import socket
import numpy as np
import math
import time
import threading
import sys
import os
import select
import psutil  # Add for process priority management
import ctypes  # For thread priority

# ROS2 imports
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy, QoSDurabilityPolicy
from sensor_msgs.msg import LaserScan
from ddsm115 import MotorControl

# Konfigurasi Global
SCAN_THRESHOLD = 8000  # Jarak aman dalam mm
DANGER_THRESHOLD = 500  # Jarak bahaya dalam mm
MIN_VALID_DISTANCE = 220  # Jarak minimum valid (mm) untuk menghindari noise
CRITICAL_DANGER_THRESHOLD = 350  # Jarak kritis untuk override UWB (mm)

# UWB UDP Configuration
UDP_IP = "192.168.102.128"
UDP_PORT = 5005

# Motor speed configuration
DEFAULT_SPEED = 80
ROTATION_FACTOR = 2
STOP_THRESHOLD = 70  # cm

# OPTIMIZATION: Reduced LIDAR sampling settings
SCAN_SKIP_POINTS = 2  # Skip every N points to reduce data processing
MOVING_AVG_WINDOW = 2  # Reduced from 3 to 2 for less memory usage

# OPTIMIZATION: More selective region monitoring (reduced angle ranges)
FRONT_REGION = (225, 315)  # Narrowed front region: 225-315° (90° arc)
LEFT_REGION = (135, 225)   # Narrowed left region: 135-225° (90° arc)
RIGHT_REGION = (315, 45)   # Narrowed right region: 315-45° (90° arc)

# Target exclusion zone
TARGET_EXCLUSION_ANGLE = 30  # degrees on each side of target

class UWBTracker:
    """Handles UWB data processing and position estimation"""
    
    def __init__(self):
        # Default bias correction values
        self.bias = {
            'A0': 50.0,  # Bias value in cm
            'A1': 50.0,  # Bias value in cm
            'A2': 50.0   # Bias value in cm
        }
        
        # Default scale factor values
        self.scale_factor = {
            'A0': 1.0,   # Scale factor
            'A1': 1.06,  # Scale factor
            'A2': 1.05   # Scale factor
        }
        
        # Target direction estimation
        self.target_direction = None  # Estimated angle to target (degrees)
        self.target_distance = None   # Estimated distance to target (mm)
    
    def apply_bias_correction(self, distances):
        """Koreksi bias dan scaling pada pengukuran jarak"""
        corrected_distances = {
            'A0': max((distances['A0'] * 100 * self.scale_factor['A0']) - self.bias['A0'], 0),
            'A1': max((distances['A1'] * 100 * self.scale_factor['A1']) - self.bias['A1'], 0),
            'A2': max((distances['A2'] * 100 * self.scale_factor['A2']) - self.bias['A2'], 0)
        }
        return corrected_distances
    
    def estimate_target_direction(self, distances):
        """Estimate the direction and distance to the UWB target based on distances"""
        # Simple triangulation to estimate direction
        A0, A1, A2 = distances['A0'], distances['A1'], distances['A2']
        
        # Convert to mm for consistency with LIDAR
        target_distance = A0 * 10  # cm to mm
        
        # Simple direction estimation
        if abs(A1 - A2) < 20:  # Target is roughly straight ahead
            target_direction = 270  # Front is 270 degrees
        elif A1 < A2:  # Target is more to the left
            target_direction = 315  # Left-front quadrant
        else:  # Target is more to the right
            target_direction = 225  # Right-front quadrant
        
        self.target_direction = target_direction
        self.target_distance = target_distance
        
        return target_direction, target_distance

class LidarProcessor:
    """Processes LIDAR data from ROS2 LaserScan messages"""
    
    def __init__(self):
        self.scan_data = {}  # Dictionary untuk menyimpan data scan (angle -> distance)
        self.lock = threading.Lock()
        
        # Status rintangan
        self.front_obstacle = False
        self.left_obstacle = False
        self.right_obstacle = False
        self.danger_zone = False
        
        # Jarak minimum di setiap region
        self.front_distance = float('inf')
        self.left_distance = float('inf')
        self.right_distance = float('inf')
        
        # Timestamp data terakhir
        self.last_scan_time = 0
        
        # Target information (from UWB)
        self.target_direction = None
        self.target_distance = None
        
        # OPTIMIZATION: Better filtering - more memory efficient
        self.distance_history = {}  # Store recent distance values for filtering
        self.moving_avg_window = MOVING_AVG_WINDOW  # Reduced window size
        
        # OPTIMIZATION: Track regions of interest to reduce processing
        self.angles_of_interest = set()
        self._precalculate_angles_of_interest()
    
    def _precalculate_angles_of_interest(self):
        """Pre-calculate important angles to reduce processing"""
        self.angles_of_interest.clear()
        
        # Only track angles in our regions of interest
        # Front region
        for angle in range(FRONT_REGION[0], FRONT_REGION[1] + 1, SCAN_SKIP_POINTS):
            self.angles_of_interest.add(angle % 360)
            
        # Left region
        for angle in range(LEFT_REGION[0], LEFT_REGION[1] + 1, SCAN_SKIP_POINTS):
            self.angles_of_interest.add(angle % 360)
            
        # Right region - handle wraparound
        if RIGHT_REGION[0] < RIGHT_REGION[1]:
            for angle in range(RIGHT_REGION[0], RIGHT_REGION[1] + 1, SCAN_SKIP_POINTS):
                self.angles_of_interest.add(angle % 360)
        else:
            for angle in range(RIGHT_REGION[0], 360, SCAN_SKIP_POINTS):
                self.angles_of_interest.add(angle)
            for angle in range(0, RIGHT_REGION[1] + 1, SCAN_SKIP_POINTS):
                self.angles_of_interest.add(angle)
    
    def set_target_info(self, direction, distance):
        """Set target information from UWB to avoid treating target as obstacle"""
        self.target_direction = direction
        self.target_distance = distance
        
        # Update angles of interest based on new target
        if direction is not None:
            # Add angles around target to exclusion zone
            start_angle = (direction - TARGET_EXCLUSION_ANGLE) % 360
            end_angle = (direction + TARGET_EXCLUSION_ANGLE) % 360
            
            # Clear old exclusion zone angles from set
            self._precalculate_angles_of_interest()
    
    def process_scan(self, scan_msg):
        """Process ROS2 LaserScan message - OPTIMIZED VERSION"""
        with self.lock:
            # Update timestamp immediately
            self.last_scan_time = time.time()
            
            # Clear old scan data
            self.scan_data.clear()
            
            # Extract ranges and angular values
            ranges = scan_msg.ranges
            angle_increment = scan_msg.angle_increment
            angle_min = scan_msg.angle_min
            
            # OPTIMIZATION: Only process every Nth point and only in regions of interest
            for i in range(0, len(ranges), SCAN_SKIP_POINTS):
                # Calculate angle in degrees
                angle_rad = angle_min + (i * angle_increment)
                angle_deg = int(math.degrees(angle_rad) % 360)
                
                # Skip if not in our angles of interest
                if angle_deg not in self.angles_of_interest:
                    continue
                
                distance = ranges[i]
                
                # Skip invalid measurements
                if distance < MIN_VALID_DISTANCE/1000.0 or math.isinf(distance):
                    continue
                
                # Convert to mm
                distance_mm = int(distance * 1000)
                
                # OPTIMIZATION: Simplified filtering to reduce CPU load
                if angle_deg in self.distance_history:
                    # Simple averaging for noise reduction
                    history = self.distance_history[angle_deg]
                    history.append(distance_mm)
                    if len(history) > self.moving_avg_window:
                        history.pop(0)
                    # Fast median approximation instead of full sorting
                    self.scan_data[angle_deg] = int(sum(history) / len(history))
                else:
                    self.distance_history[angle_deg] = [distance_mm]
                    self.scan_data[angle_deg] = distance_mm
            
            # Analyze obstacles - quick pass
            self._analyze_obstacles()
    
    def _is_angle_in_region(self, angle, region):
        """Check if angle is in specified region, handling wraparound at 360°"""
        start, end = region
        if start <= end:
            return start <= angle <= end
        else:  # Wraparound case (e.g. 350° to 10°)
            return angle >= start or angle <= end
    
    def _is_angle_near_target(self, angle):
        """Check if this angle is near the UWB target direction"""
        if self.target_direction is None:
            return False
            
        # Calculate angular distance to target - optimized version
        angular_dist = min(
            abs(angle - self.target_direction),
            360 - abs(angle - self.target_direction)
        )
        
        # If angle is within exclusion zone of target, return True
        return angular_dist < TARGET_EXCLUSION_ANGLE
    
    def _analyze_obstacles(self):
        """Analyze scan data to detect obstacles in different regions - OPTIMIZED"""
        if not self.scan_data:
            # No valid scan data
            return
        
        # Reset obstacle status
        self.front_obstacle = False
        self.left_obstacle = False
        self.right_obstacle = False
        self.danger_zone = False
        
        # Reset distances
        self.front_distance = float('inf')
        self.left_distance = float('inf')
        self.right_distance = float('inf')
        
        # OPTIMIZATION: Count obstacles in bins rather than individual points
        front_obstacles = 0
        left_obstacles = 0
        right_obstacles = 0
        min_detected_points = 3  # Minimum points to confirm obstacle (reduces false positives)
        
        # Analyze each region
        for angle, distance in self.scan_data.items():
            # Skip points that are near the UWB target direction
            if self._is_angle_near_target(angle):
                continue
                
            # Front region
            if self._is_angle_in_region(angle, FRONT_REGION):
                if distance < self.front_distance:
                    self.front_distance = distance
                if distance < SCAN_THRESHOLD:
                    front_obstacles += 1
                if distance < DANGER_THRESHOLD:
                    self.danger_zone = True
            
            # Left region
            elif self._is_angle_in_region(angle, LEFT_REGION):
                if distance < self.left_distance:
                    self.left_distance = distance
                if distance < SCAN_THRESHOLD:
                    left_obstacles += 1
            
            # Right region
            elif self._is_angle_in_region(angle, RIGHT_REGION):
                if distance < self.right_distance:
                    self.right_distance = distance
                if distance < SCAN_THRESHOLD:
                    right_obstacles += 1
        
        # Set obstacle flags based on count thresholds to avoid single-point noise
        self.front_obstacle = front_obstacles >= min_detected_points
        self.left_obstacle = left_obstacles >= min_detected_points
        self.right_obstacle = right_obstacles >= min_detected_points
    
    def get_obstacle_status(self):
        """Get current obstacle status"""
        with self.lock:
            scan_age = time.time() - self.last_scan_time
            data_valid = scan_age < 0.5  # Data valid if less than 0.5 second old
            
            status = {
                'front': {
                    'obstacle': self.front_obstacle if data_valid else False,
                    'distance': self.front_distance if data_valid else float('inf')
                },
                'left': {
                    'obstacle': self.left_obstacle if data_valid else False,
                    'distance': self.left_distance if data_valid else float('inf')
                },
                'right': {
                    'obstacle': self.right_obstacle if data_valid else False,
                    'distance': self.right_distance if data_valid else float('inf')
                },
                'danger_zone': self.danger_zone if data_valid else False,
                'data_valid': data_valid,
                'scan_points': len(self.scan_data) if data_valid else 0,
                'scan_age': scan_age
            }
            
            return status
    
    def get_safe_direction(self):
        """Determine the safest direction to move based on obstacles"""
        status = self.get_obstacle_status()
        
        if not status['data_valid']:
            print("Warning: LIDAR data not valid or too old")
            return None
        
        if status['danger_zone']:
            return "STOP"
            
        if not status['front']['obstacle'] and not status['left']['obstacle'] and not status['right']['obstacle']:
            return "FORWARD"  # No obstacles
            
        # If front is blocked
        if status['front']['obstacle']:
            # Both sides clear - choose the one with more space
            if not status['left']['obstacle'] and not status['right']['obstacle']:
                if status['left']['distance'] > status['right']['distance']:
                    return "LEFT"
                else:
                    return "RIGHT"
            # Only left is clear
            elif not status['left']['obstacle']:
                return "LEFT"
            # Only right is clear
            elif not status['right']['obstacle']:
                return "RIGHT"
            # All directions blocked - choose least bad option
            else:
                distances = [
                    ('FORWARD', status['front']['distance']),
                    ('LEFT', status['left']['distance']),
                    ('RIGHT', status['right']['distance'])
                ]
                best_direction = max(distances, key=lambda x: x[1])[0]
                return best_direction
        
        # Front is clear but sides have obstacles
        return "FORWARD"

class RobotController:
    """Controls robot movement based on UWB and LIDAR data"""
    
    def __init__(self, r_wheel_port, l_wheel_port):
        # Motor controllers
        self.right_motor = MotorControl(device=r_wheel_port)
        self.left_motor = MotorControl(device=l_wheel_port)
        self.right_motor.set_drive_mode(1, 2)
        self.left_motor.set_drive_mode(1, 2)
        
        # Speed configuration
        self.speed = DEFAULT_SPEED
        self.rotation_factor = ROTATION_FACTOR
        self.stop_threshold = STOP_THRESHOLD
        
        # Status flags
        self.obstacle_avoidance_active = False
        self.last_command_time = time.time()
        self.current_direction = "STOP"
        
        # OPTIMIZATION: Command throttling to reduce motor controller load
        self.command_throttle_time = 0.1  # seconds minimum between commands
        self.last_right_speed = 0
        self.last_left_speed = 0
    
    def move(self, right_speed, left_speed):
        """Move the robot with specified motor speeds - OPTIMIZED"""
        current_time = time.time()
        
        # OPTIMIZATION: Only send commands if speed has changed or enough time has passed
        if (current_time - self.last_command_time >= self.command_throttle_time or
            right_speed != self.last_right_speed or
            left_speed != self.last_left_speed):
            
            self.right_motor.send_rpm(1, right_speed)
            self.left_motor.send_rpm(1, left_speed)
            
            self.last_command_time = current_time
            self.last_right_speed = right_speed
            self.last_left_speed = left_speed
    
    def stop(self):
        """Stop the robot"""
        self.move(0, 0)
        self.current_direction = "STOP"
    
    def handle_obstacle_avoidance(self, lidar, target_in_view=False):
        """Process LIDAR data for obstacle avoidance"""
        # Get obstacle status and safe direction
        status = lidar.get_obstacle_status()
        safe_direction = lidar.get_safe_direction()
        
        # If we're close to the target and the target is in view, ignore obstacles
        if target_in_view and lidar.target_distance and lidar.target_distance < STOP_THRESHOLD * 10:
            return False
        
        # Check if LIDAR data is valid and not too old
        if not status['data_valid'] or safe_direction is None:
            if status['scan_age'] > 0.5:  # Data older than 0.5 seconds
                print(f"LIDAR data too old: {status['scan_age']:.2f} seconds")
            return False
        
        # Print obstacle status for debugging - OPTIMIZED to print less frequently
        current_time = time.time()
        if current_time % 2 < 0.1:  # Print only occasionally to reduce CPU load
            print(f"Front: {'BLOCKED' if status['front']['obstacle'] else 'clear'} ({status['front']['distance']}mm)")
            print(f"Left: {'BLOCKED' if status['left']['obstacle'] else 'clear'} ({status['left']['distance']}mm)")
            print(f"Right: {'BLOCKED' if status['right']['obstacle'] else 'clear'} ({status['right']['distance']}mm)")
            print(f"Danger Zone: {'YES' if status['danger_zone'] else 'NO'}")
        
        # Handle obstacle avoidance based on safe direction
        if safe_direction == "STOP" or status['danger_zone']:
            print("DANGER ZONE DETECTED - STOPPING")
            self.stop()
            self.obstacle_avoidance_active = True
            return True
            
        elif safe_direction == "LEFT":
            self.move(-self.speed, self.speed/self.rotation_factor)
            self.current_direction = "LEFT"
            self.obstacle_avoidance_active = True
            return True
            
        elif safe_direction == "RIGHT":
            self.move(-self.speed/self.rotation_factor, self.speed)
            self.current_direction = "RIGHT"
            self.obstacle_avoidance_active = True
            return True
            
        else:  # "FORWARD" or None
            # No obstacle that requires immediate action
            self.obstacle_avoidance_active = False
            return False
    
    def process_uwb_control(self, uwb_distances):
        """Process UWB data to control robot movement"""
        A0, A1, A2 = uwb_distances['A0'], uwb_distances['A1'], uwb_distances['A2']
        
        # Print UWB distances - OPTIMIZED to print less frequently
        current_time = time.time()
        if current_time % 2 < 0.1:  # Print only occasionally
            print(f"A0: {A0:.2f} | A1: {A1:.2f} | A2: {A2:.2f}")
        
        # Logic for UWB-based control
        if A0 <= self.stop_threshold:
            self.stop()
            return
        
        # Control logic based on UWB distances
        if A0 < A1 and A0 < A2 and (-20 < (A2-A1) < 20):
            self.move(-self.speed, self.speed)
            self.current_direction = "FORWARD"
        elif (A1 < A2 and A0 < A2):
            self.move(-self.speed, self.speed/self.rotation_factor)  # Left serong 
            self.current_direction = "LEFT"
        elif (A2 < A1 and A0 < A1):
            self.move(-self.speed/self.rotation_factor, self.speed)  # Right serong
            self.current_direction = "RIGHT"
        elif (A2 < A1):
            self.move(-self.speed/self.rotation_factor, self.speed)  # Right rotation
            self.current_direction = "RIGHT"
        elif (A1 < A2):
            self.move(-self.speed, self.speed/self.rotation_factor)   # Left rotation
            self.current_direction = "LEFT"
        elif (A0 > A1 or A0 > A2):
            self.move(self.speed/self.rotation_factor, self.speed/self.rotation_factor) #Rotation
            self.current_direction = "ROTATE"
    
    def process_control(self, uwb_distances, lidar):
        """Main control logic integrating UWB and LIDAR data"""
        # Determine if we have a clear view of the target and update LIDAR with target info
        target_direction, target_distance = uwb_tracker.estimate_target_direction(uwb_distances)
        lidar.set_target_info(target_direction, target_distance)
        
        # Check if target is in close proximity 
        target_in_view = (
            uwb_distances['A0'] < 200 and  # Within 2 meters
            abs(uwb_distances['A1'] - uwb_distances['A2']) < 30  # Roughly centered
        )
        
        # First priority: Obstacle avoidance (safety), unless target is very close
        obstacle_action_taken = self.handle_obstacle_avoidance(lidar, target_in_view)
        
        # If LIDAR didn't require immediate action, use UWB for following
        if not obstacle_action_taken:
            self.process_uwb_control(uwb_distances)

# OPTIMIZATION: Set higher thread priority for timely data processing
def set_high_priority():
    """Set the current process/thread to high priority"""
    try:
        # Set process priority (Unix)
        os.nice(-10)  # Lower niceness = higher priority
    except:
        pass
    
    try:
        # Set process priority (Windows)
        p = psutil.Process(os.getpid())
        p.nice(psutil.HIGH_PRIORITY_CLASS)
    except:
        pass

# OPTIMIZATION: Thread with priority control
class PriorityThread(threading.Thread):
    def __init__(self, *args, priority=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.priority = priority
        
    def run(self):
        if self.priority == "HIGH":
            set_high_priority()
        super().run()

class FollowingRobotNode(Node):
    """ROS2 Node for human-following robot with obstacle avoidance"""
    
    def __init__(self):
        super().__init__('following_robot_node')
        
        # Set process priority
        set_high_priority()
        
        # Configuration
        self.r_wheel_port = "/dev/ttyRS485-2"
        self.l_wheel_port = "/dev/ttyRS485-1"
        
        # Initialize components
        self.uwb_tracker = UWBTracker()
        self.lidar = LidarProcessor()
        self.controller = RobotController(self.r_wheel_port, self.l_wheel_port)
        
        # OPTIMIZATION: Configure LIDAR specific QoS profile for RPLidar A2M12
        # Optimize for RPLidar A2M12
        lidar_qos = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,  # Less reliable but faster
            durability=QoSDurabilityPolicy.VOLATILE,       # No persistence needed
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=1  # Only keep latest scan
        )
        
        # Create LiDAR subscription with higher QoS for better responsiveness
        self.scan_subscription = self.create_subscription(
            LaserScan,
            '/scan',  # Topic name - adjust if your RPLidar node publishes to a different topic
            self.scan_callback,
            qos_profile=lidar_qos)
        
        # Create socket for UWB data and make it non-blocking
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((UDP_IP, UDP_PORT))
        self.sock.setblocking(False)  # Fully non-blocking
        
        # UWB data
        self.raw_uwb_distances = {'A0': 1000, 'A1': 1000, 'A2': 1000}
        self.corrected_uwb_distances = {'A0': 1000, 'A1': 1000, 'A2': 1000}
        
        # Status control
        self.running = True
        self.last_uwb_update = 0
        
        # OPTIMIZATION: Use separate threads for different tasks with proper priorities
        # Create timers with longer intervals to reduce CPU usage
        self.control_timer = self.create_timer(0.1, self.control_loop)  # 10Hz instead of 20Hz
        
        # Performance monitoring
        self.last_lidar_time = time.time()
        self.lidar_update_count = 0
        self.lidar_update_rate = 0
        
        # OPTIMIZATION: Use separate thread for UWB processing to avoid blocking
        self.uwb_thread = PriorityThread(
            target=self.uwb_processing_loop,
            priority="HIGH",
            daemon=True
        )
        self.uwb_thread.start()
        
        self.get_logger().info('Optimized Following Robot Node started')
    
    def scan_callback(self, msg):
        """Process incoming LaserScan messages"""
        # Calculate update rate
        current_time = time.time()
        self.lidar_update_count += 1
        
        if current_time - self.last_lidar_time > 5.0:  # Only update stats every 5 seconds
            self.lidar_update_rate = self.lidar_update_count / 5.0
            self.lidar_update_count = 0
            self.last_lidar_time = current_time
            self.get_logger().info(f"LiDAR update rate: {self.lidar_update_rate:.1f} Hz")
        
        # Process scan data
        self.lidar.process_scan(msg)
    
    def uwb_processing_loop(self):
        """Dedicated thread for UWB data processing"""
        while self.running:
            try:
                # Non-blocking UWB data reception
                ready = select.select([self.sock], [], [], 0.01)
                if ready[0]:
                    data, addr = self.sock.recvfrom(1024)
                    parts = data.decode().split(",")
                    
                    # Update raw distances
                    self.raw_uwb_distances = {
                        'A0': float(parts[0]),
                        'A1': float(parts[1]),
                        'A2': float(parts[2])
                    }
                    
                    # Apply bias correction
                    self.corrected_uwb_distances = self.uwb_tracker.apply_bias_correction(self.raw_uwb_distances)
                    self.last_uwb_update = time.time()
            except Exception as e:
                # Ignore common non-blocking socket exceptions
                if "Resource temporarily unavailable" not in str(e):
                    self.get_logger().error(f"UWB error: {e}")
            
            # Sleep to reduce CPU usage
            time.sleep(0.01)
    
    def control_loop(self):
        """Main control loop executed on timer"""
        if not self.running:
            return
        
        try:
            # Calculate UWB data age
            uwb_data_age = time.time() - self.last_uwb_update
            uwb_data_valid = uwb_data_age < 1.0  # Valid if less than 1 second old
            
            # Process control based on sensor data
            if uwb_data_valid:
                # We have valid UWB data - use integrated control
                self.controller.process_control(self.corrected_uwb_distances, self.lidar)
            else:
                # No valid UWB data - just do obstacle avoidance
                self.controller.handle_obstacle_avoidance(self.lidar)
                
        except Exception as e:
            self.get_logger().error(f"Error in control loop: {e}")
    
    def stop(self):
        """Stop the robot and clean up"""
        self.running = False
        self.controller.stop()
        self.sock.close()
        self.get_logger().info("Robot systems shut down.")

def main(args=None):
    # Initialize ROS2
    rclpy.init(args=args)
    
    # Create global reference to UWB tracker for coordinate system 
    global uwb_tracker
    uwb_tracker = UWBTracker()
    
    # Create node
    node = FollowingRobotNode()
    
    try:
        # Run until interrupted
        rclpy.spin(node)
    except KeyboardInterrupt:
        print("\nUser interrupted. Shutting down...")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        # Clean up
        node.stop()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()

