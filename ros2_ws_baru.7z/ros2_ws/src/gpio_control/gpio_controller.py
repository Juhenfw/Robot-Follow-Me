import rclpy
from rclpy.node import Node
import RPi.GPIO as GPIO

class GpioController(Node):
    def __init__(self):
        super().__init__('gpio_controller')

        # Set GPIO mode
        GPIO.setmode(GPIO.BCM)

        # Set pin untuk LED (misalnya pin 17)
        self.led_pin = 17
        GPIO.setup(self.led_pin, GPIO.OUT)

        # Hidupkan LED saat program dimulai
        GPIO.output(self.led_pin, GPIO.HIGH)
        self.get_logger().info("LED ON - Status Ready")

    def cleanup(self):
        # Pastikan GPIO dibersihkan setelah program selesai
        GPIO.output(self.led_pin, GPIO.LOW)
        GPIO.cleanup()
        self.get_logger().info("LED OFF - Status Error")

def main(args=None):
    rclpy.init(args=args)
    gpio_controller = GpioController()

    try:
        rclpy.spin(gpio_controller)
    except KeyboardInterrupt:
        pass
    finally:
        gpio_controller.cleanup()

if __name__ == '__main__':
    main()
