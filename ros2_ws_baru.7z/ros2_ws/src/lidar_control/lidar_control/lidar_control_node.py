# import rclpy
# from rclpy.node import Node
# from sensor_msgs.msg import LaserScan
# from geometry_msgs.msg import Twist

# class LidarControlNode(Node):
#     def __init__(self):
#         super().__init__('lidar_control_node')
#         # Publisher untuk perintah gerakan
#         self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
#         # Subscriber untuk data LIDAR
#         self.subscription = self.create_subscription(
#             LaserScan,
#             '/scan',
#             self.listener_callback,
#             10
#         )
#         self.get_logger().info('LidarControlNode has been started.')

#     def listener_callback(self, msg):
#         move_cmd = Twist()
#         # Ambil jarak terdekat yang terdeteksi oleh LIDAR
#         min_distance = min(msg.ranges)

#         # Jika ada halangan dalam jarak kurang dari 1 meter, robot berhenti
#         if min_distance < 1.0:
#             move_cmd.linear.x = 0.0  # Stop robot
#             move_cmd.angular.z = 0.0
#         else:
#             move_cmd.linear.x = 0.2  # Laju bergerak robot
#             move_cmd.angular.z = 0.0  # Tidak ada rotasi

#         # Publikasikan perintah gerak
#         self.publisher_.publish(move_cmd)

# def main(args=None):
#     rclpy.init(args=args)
#     lidar_control_node = LidarControlNode()
#     rclpy.spin(lidar_control_node)
#     lidar_control_node.destroy_node()
#     rclpy.shutdown()

# if __name__ == '__main__':
#     main()

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan

class LidarControlNode(Node):
    def __init__(self):
        super().__init__('lidar_control_node')
        # Subscriber untuk data LIDAR
        self.subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.listener_callback,
            10
        )
        self.get_logger().info('LidarControlNode has been started.')

    def listener_callback(self, msg):
        # Ambil jarak terdekat yang terdeteksi oleh LIDAR
        min_distance = min(msg.ranges)
        
        # Print jarak terdekat di terminal
        print(f"Jarak terdekat dari LIDAR: {min_distance:.2f} meter")

        # Jika ada halangan dalam jarak kurang dari 1 meter, robot berhenti
        if min_distance < 1.0:
            print("Robot berhenti (halangan terdeteksi).")
        else:
            print("Robot bergerak maju.")

def main(args=None):
    rclpy.init(args=args)
    lidar_control_node = LidarControlNode()
    rclpy.spin(lidar_control_node)
    lidar_control_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
