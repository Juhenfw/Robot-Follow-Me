from launch import LaunchDescription
from launch.actions import ExecuteProcess

def generate_launch_description():
    return LaunchDescription([
        # Launch using direct Python execution
        ExecuteProcess(
            cmd=['python3', '/home/ympipa/ros2_ws/src/gamepad_robot_controller/gamepad_robot_controller/gamepad_controller_node.py'],
            output='screen',
            name='gamepad_controller'
        ),
    ])
