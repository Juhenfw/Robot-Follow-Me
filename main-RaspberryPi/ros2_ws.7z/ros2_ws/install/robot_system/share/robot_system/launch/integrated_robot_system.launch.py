from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
import os
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # Declare arguments
    default_mode_arg = DeclareLaunchArgument(
        'default_mode',
        default_value='manual',
        description='Default robot operation mode: manual or autonomous'
    )
    
    # Find package shares
    try:
        lidar_pkg_dir = get_package_share_directory('rplidar_ros')
    except:
        lidar_pkg_dir = ''
        print("Warning: rplidar_ros package not found, LiDAR functionality will be disabled")
    
    try:
        gamepad_pkg_dir = get_package_share_directory('gamepad_robot_controller')
    except:
        gamepad_pkg_dir = ''
        print("Warning: gamepad_robot_controller package not found, gamepad functionality will be disabled")
    
    # Include RPLidar launch file
    rplidar_launch = None
    if lidar_pkg_dir:
        try:
            rplidar_launch = IncludeLaunchDescription(
                PythonLaunchDescriptionSource([
                    os.path.join(lidar_pkg_dir, 'launch', 'view_rplidar_a2m12_launch.py')
                ])
            )
        except:
            print("Warning: RPLidar launch file not found")
    
    # Launch gamepad controller node
    gamepad_node = None
    if gamepad_pkg_dir:
        try:
            gamepad_node = Node(
                package='gamepad_robot_controller',
                executable='gamepad_controller_node.py',
                name='gamepad_controller',
                output='screen'
            )
        except:
            print("Warning: Gamepad controller executable not found")
    
    # Launch robot system nodes
    mode_controller_node = Node(
        package='robot_system',
        executable='mode_controller',
        name='mode_controller',
        parameters=[{
            'default_mode': LaunchConfiguration('default_mode')
        }],
        output='screen'
    )
    
    gamepad_wrapper_node = Node(
        package='robot_system',
        executable='gamepad_wrapper',
        name='gamepad_wrapper',
        output='screen'
    )
    
    autonomous_node = Node(
        package='robot_system',
        executable='basic_autonomous',
        name='basic_autonomous',
        parameters=[{
            'safety_distance': 0.5,
            'max_speed': 0.2,
            'max_rotation': 0.5
        }],
        output='screen'
    )
    
    # Build launch description
    ld = LaunchDescription([default_mode_arg])
    
    # Add nodes
    ld.add_action(mode_controller_node)
    ld.add_action(gamepad_wrapper_node)
    ld.add_action(autonomous_node)
    
    # Add conditional nodes
    if rplidar_launch:
        ld.add_action(rplidar_launch)
    if gamepad_node:
        ld.add_action(gamepad_node)
    
    return ld
