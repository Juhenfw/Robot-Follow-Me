from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration

def generate_launch_description():
    # Declare launch arguments with default values
    serial_port_arg = DeclareLaunchArgument(
        'serial_port',
        default_value='/dev/ttyLIDAR',
        description='RPLidar serial port'
    )
    
    serial_baudrate_arg = DeclareLaunchArgument(
        'serial_baudrate',
        default_value='256000',  # A2M12 uses 115200 baud
        description='RPLidar baudrate'
    )
    
    frame_id_arg = DeclareLaunchArgument(
        'frame_id',
        default_value='laser',
        description='TF frame ID for laser scan'
    )
    
    inverted_arg = DeclareLaunchArgument(
        'inverted',
        default_value='false',
        description='Indicate if lidar is mounted upside-down'
    )
    
    angle_compensate_arg = DeclareLaunchArgument(
        'angle_compensate',
        default_value='true',
        description='Enable/disable angle compensation'
    )

    # Get the substitution for each argument
    serial_port = LaunchConfiguration('serial_port')
    serial_baudrate = LaunchConfiguration('serial_baudrate')
    frame_id = LaunchConfiguration('frame_id')
    inverted = LaunchConfiguration('inverted')
    angle_compensate = LaunchConfiguration('angle_compensate')

    # Create the RPLidar node - using the correct executable name
    rplidar_node = Node(
        package='rplidar_ros',
        executable='rplidar_composition',  # This is the executable name from your error logs
        name='rplidar_node',
        output='screen',
        parameters=[{
            'serial_port': serial_port,
            'serial_baudrate': serial_baudrate,
            'frame_id': frame_id,
            'inverted': inverted,
            'angle_compensate': angle_compensate,
        }]
    )

    return LaunchDescription([
        serial_port_arg,
        serial_baudrate_arg,
        frame_id_arg,
        inverted_arg,
        angle_compensate_arg,
        rplidar_node
    ])
