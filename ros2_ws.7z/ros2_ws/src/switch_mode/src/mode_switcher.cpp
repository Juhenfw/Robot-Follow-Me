#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "sensor_msgs/msg/joy.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include <termios.h>
#include <unistd.h>
#include <thread>
#include <chrono>
#include <algorithm>
#include <vector>
#include <cmath>

enum class ControlMode {
  MANUAL,
  AUTONOMOUS,
  IDLE
};

class ModeSwitcher : public rclcpp::Node
{
public:
  ModeSwitcher() : Node("mode_switcher"), current_mode_(ControlMode::IDLE)
  {
    // Create publisher for robot velocity commands
    cmd_vel_pub_ = this->create_publisher<geometry_msgs::msg::Twist>("cmd_vel", 10);
    
    // Create publisher for current mode
    mode_pub_ = this->create_publisher<std_msgs::msg::String>("current_mode", 10);
    
    // Subscribe to manual control commands
    manual_sub_ = this->create_subscription<geometry_msgs::msg::Twist>(
      "manual_cmd_vel", 10, std::bind(&ModeSwitcher::manual_callback, this, std::placeholders::_1));
    
    // Subscribe to joystick for mode switching
    joy_sub_ = this->create_subscription<sensor_msgs::msg::Joy>(
      "joy", 10, std::bind(&ModeSwitcher::joy_callback, this, std::placeholders::_1));
    
    // Subscribe to lidar scan data for autonomous mode
    scan_sub_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
      "scan", 10, std::bind(&ModeSwitcher::lidar_callback, this, std::placeholders::_1));
    
    // Parameters for obstacle avoidance
    this->declare_parameter("min_safe_distance", 0.5);  // Minimum safe distance in meters
    this->declare_parameter("detection_angle", 180.0);  // Angle range in front to check (degrees)
    this->declare_parameter("max_linear_speed", 0.3);   // Maximum linear speed
    this->declare_parameter("max_angular_speed", 1.0);  // Maximum angular speed
    this->declare_parameter("sector_count", 8);         // Number of sectors to divide the scan
    
    min_safe_distance_ = this->get_parameter("min_safe_distance").as_double();
    detection_angle_ = this->get_parameter("detection_angle").as_double();
    max_linear_speed_ = this->get_parameter("max_linear_speed").as_double();
    max_angular_speed_ = this->get_parameter("max_angular_speed").as_double();
    sector_count_ = this->get_parameter("sector_count").as_int();
    
    // Timer for publishing current mode
    timer_ = this->create_wall_timer(
      std::chrono::milliseconds(500),
      std::bind(&ModeSwitcher::publish_mode, this));
    
    // Start keyboard listening thread
    keyboard_thread_ = std::thread(&ModeSwitcher::keyboard_callback, this);
    
    RCLCPP_INFO(this->get_logger(), "Mode switcher initialized in IDLE mode");
    RCLCPP_INFO(this->get_logger(), "Press 'm' for MANUAL mode, 'a' for AUTONOMOUS mode, 'i' for IDLE mode");
  }
  
  ~ModeSwitcher()
  {
    if (keyboard_thread_.joinable()) {
      keyboard_thread_.join();
    }
  }

private:
  void manual_callback(const geometry_msgs::msg::Twist::SharedPtr msg)
  {
    if (current_mode_ == ControlMode::MANUAL) {
      cmd_vel_pub_->publish(*msg);
    }
  }
  
  void joy_callback(const sensor_msgs::msg::Joy::SharedPtr joy_msg)
  {
    // Toggle mode on button press (using button 0, usually 'A' on Xbox controllers)
    if (joy_msg->buttons.size() > 0 && joy_msg->buttons[0] == 1 && !button_pressed_) {
      button_pressed_ = true;
      
      if (current_mode_ == ControlMode::MANUAL) {
        current_mode_ = ControlMode::AUTONOMOUS;
        RCLCPP_INFO(this->get_logger(), "Switching to AUTONOMOUS mode");
      } else if (current_mode_ == ControlMode::AUTONOMOUS) {
        current_mode_ = ControlMode::MANUAL;
        RCLCPP_INFO(this->get_logger(), "Switching to MANUAL mode");
      } else {
        current_mode_ = ControlMode::MANUAL;
        RCLCPP_INFO(this->get_logger(), "Switching to MANUAL mode");
      }
    } else if (joy_msg->buttons.size() > 0 && joy_msg->buttons[0] == 0) {
      button_pressed_ = false;
    }
  }
  
  void lidar_callback(const sensor_msgs::msg::LaserScan::SharedPtr scan_msg)
  {
    // Only process LiDAR data if in autonomous mode
    if (current_mode_ == ControlMode::AUTONOMOUS) {
      auto cmd = process_scan(*scan_msg);
      cmd_vel_pub_->publish(cmd);
    }
  }
  
  // Non-blocking keyboard input setup
  char getch() {
    char buf = 0;
    struct termios old = {0};
    if (tcgetattr(0, &old) < 0)
        return 0;
    old.c_lflag &= ~ICANON;
    old.c_lflag &= ~ECHO;
    old.c_cc[VMIN] = 1;
    old.c_cc[VTIME] = 0;
    if (tcsetattr(0, TCSANOW, &old) < 0)
        return 0;
    if (read(0, &buf, 1) < 0)
        return 0;
    old.c_lflag |= ICANON;
    old.c_lflag |= ECHO;
    if (tcsetattr(0, TCSADRAIN, &old) < 0)
        return 0;
    return buf;
  }
  
  void keyboard_callback()
  {
    RCLCPP_INFO(this->get_logger(), "Keyboard thread started");
    while (rclcpp::ok()) {
      char c = getch();
      
      switch (c) {
        case 'm':
        case 'M':
          if (current_mode_ != ControlMode::MANUAL) {
            current_mode_ = ControlMode::MANUAL;
            RCLCPP_INFO(this->get_logger(), "Switching to MANUAL mode");
          }
          break;
        case 'a':
        case 'A':
          if (current_mode_ != ControlMode::AUTONOMOUS) {
            current_mode_ = ControlMode::AUTONOMOUS;
            RCLCPP_INFO(this->get_logger(), "Switching to AUTONOMOUS mode");
          }
          break;
        case 'i':
        case 'I':
          if (current_mode_ != ControlMode::IDLE) {
            current_mode_ = ControlMode::IDLE;
            RCLCPP_INFO(this->get_logger(), "Switching to IDLE mode");
            // Publish zero velocity to stop the robot
            auto stop_msg = std::make_unique<geometry_msgs::msg::Twist>();
            cmd_vel_pub_->publish(std::move(*stop_msg));
          }
          break;
        case 'q':
        case 'Q':
          RCLCPP_INFO(this->get_logger(), "Quit command received");
          rclcpp::shutdown();
          return;
        default:
          break;
      }
    }
  }
  
  void publish_mode()
  {
    auto msg = std::make_unique<std_msgs::msg::String>();
    
    switch (current_mode_) {
      case ControlMode::MANUAL:
        msg->data = "MANUAL";
        break;
      case ControlMode::AUTONOMOUS:
        msg->data = "AUTONOMOUS";
        break;
      case ControlMode::IDLE:
        msg->data = "IDLE";
        break;
    }
    
    mode_pub_->publish(std::move(*msg));
  }
  
  // Obstacle avoidance algorithm
  geometry_msgs::msg::Twist process_scan(const sensor_msgs::msg::LaserScan& scan)
  {
    geometry_msgs::msg::Twist cmd_vel;
    cmd_vel.linear.x = 0.0;
    cmd_vel.angular.z = 0.0;
    
    // Calculate the range of indices that correspond to our detection angle
    float angle_increment = scan.angle_increment;
    int mid_index = (scan.ranges.size() / 2);
    int angle_range = static_cast<int>((detection_angle_ * M_PI / 180.0) / angle_increment / 2);
    int start_index = std::max(0, mid_index - angle_range);
    int end_index = std::min(static_cast<int>(scan.ranges.size() - 1), mid_index + angle_range);
    
    // Divide the scan range into sectors
    std::vector<std::vector<float>> sectors(sector_count_);
    int sector_size = (end_index - start_index) / sector_count_;
    
    for (int i = 0; i < sector_count_; i++) {
      int sector_start = start_index + i * sector_size;
      int sector_end = (i == sector_count_ - 1) ? end_index : sector_start + sector_size;
      
      for (int j = sector_start; j < sector_end; j++) {
        if (j < scan.ranges.size() && std::isfinite(scan.ranges[j]) && 
            scan.ranges[j] >= scan.range_min && scan.ranges[j] <= scan.range_max) {
          sectors[i].push_back(scan.ranges[j]);
        }
      }
    }
    
    // Find minimum distance in each sector
    std::vector<float> min_distances(sector_count_, std::numeric_limits<float>::max());
    bool obstacle_detected = false;
    
    for (int i = 0; i < sector_count_; i++) {
      if (!sectors[i].empty()) {
        min_distances[i] = *std::min_element(sectors[i].begin(), sectors[i].end());
        if (min_distances[i] < min_safe_distance_) {
          obstacle_detected = true;
        }
      }
    }
    
    // Main obstacle avoidance algorithm
    if (obstacle_detected) {
      // Find the sector with the most space (maximum distance)
      int best_sector = 0;
      float max_distance = 0.0;
      
      for (int i = 0; i < sector_count_; i++) {
        if (!sectors[i].empty() && min_distances[i] > max_distance) {
          max_distance = min_distances[i];
          best_sector = i;
        }
      }
      
      // Calculate the heading to the best sector
      float target_angle = (best_sector - sector_count_ / 2) * (detection_angle_ / sector_count_) * (M_PI / 180.0);
      
      // Adjust linear and angular speed based on obstacle proximity
      float min_front_distance = min_distances[sector_count_ / 2];
      float obstacle_factor = std::min(1.0f, min_front_distance / min_safe_distance_);
      
      // Set motion commands
      cmd_vel.linear.x = std::max(0.0, max_linear_speed_ * obstacle_factor);
      cmd_vel.angular.z = max_angular_speed_ * target_angle;
      
      // Emergency stop if obstacle is very close in front
      if (min_front_distance < min_safe_distance_ * 0.5) {
        cmd_vel.linear.x = 0.0;
        // Turn toward the best direction
        cmd_vel.angular.z = (target_angle > 0) ? max_angular_speed_ : -max_angular_speed_;
      }
      
      RCLCPP_INFO(this->get_logger(), 
                 "Obstacle detected! Distance: %.2f m, Turning to sector %d (angle: %.2f rad)",
                 min_front_distance, best_sector, target_angle);
    } else {
      // No obstacles - move forward
      cmd_vel.linear.x = max_linear_speed_;
      cmd_vel.angular.z = 0.0;
    }
    
    return cmd_vel;
  }

  ControlMode current_mode_;
  bool button_pressed_ = false;
  
  // Parameters for obstacle avoidance
  double min_safe_distance_;
  double detection_angle_;
  double max_linear_speed_;
  double max_angular_speed_;
  int sector_count_;
  
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr mode_pub_;
  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr manual_sub_;
  rclcpp::Subscription<sensor_msgs::msg::Joy>::SharedPtr joy_sub_;
  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr scan_sub_;
  rclcpp::TimerBase::SharedPtr timer_;
  
  std::thread keyboard_thread_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<ModeSwitcher>());
  rclcpp::shutdown();
  return 0;
}
