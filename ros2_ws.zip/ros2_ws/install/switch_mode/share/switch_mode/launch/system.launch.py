from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess
import os

def generate_launch_description():
    return LaunchDescription([
        # Launch RPLidar driver
        Node(
            package='rplidar_ros',
            executable='rplidar_composition',
            name='rplidar_node',
            parameters=[{
                'serial_port': '/dev/ttyLIDAR',
                'serial_baudrate': 256000,  # A2M12 baudrate
                'frame_id': 'laser',
                'inverted': False,
                'angle_compensate': True,
            }],
            output='screen'
        ),
        
        # Launch gamepad controller - using ExecuteProcess for a Python script
        ExecuteProcess(
            cmd=['python3', '/home/ympipa/ros2_ws/src/gamepad_robot_controller/gamepad_robot_controller/gamepad_controller_node.py'],
            output='screen'
        ),
        
        # Launch mode switcher
        Node(
            package='switch_mode',
            executable='mode_switcher',
            name='mode_switcher',
            output='screen'
        ),
        
        # Add TF transformer
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='base_to_laser_broadcaster',
            arguments=['0.0', '0.0', '0.2', '0.0', '0.0', '0.0', 'base_link', 'laser']
        ),
    ])
