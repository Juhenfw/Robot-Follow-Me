#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan, Joy
from std_msgs.msg import Float32, String
from geometry_msgs.msg import Twist
import time
import os
import signal
import sys
import math
import random
import threading
import select

# Import motor control library
try:
    from gamepad_robot_controller.ddsm115 import MotorControl
except ImportError:
    print("Warning: ddsm115 module not found. Running in simulation mode.")
    MotorControl = None

class ModeSwitcherNode(Node):
    def __init__(self):
        super().__init__('mode_switcher')
        
        # Define operating modes
        self.MANUAL_MODE = 'manual'
        self.AUTO_MODE = 'autonomous'
        self.IDLE_MODE = 'idle'
        self.current_mode = self.IDLE_MODE
        
        # === Motor Controller Parameters ===
        self.declare_parameter('r_wheel_port', '/dev/ttyRS485-1')
        self.declare_parameter('l_wheel_port', '/dev/ttyRS485-2')
        self.declare_parameter('update_rate', 30.0)  # Hz
        
        self.r_wheel_port = self.get_parameter('r_wheel_port').value
        self.l_wheel_port = self.get_parameter('l_wheel_port').value
        self.update_rate = self.get_parameter('update_rate').value
        
        # === Object Avoidance Parameters ===
        self.declare_parameter('min_safe_distance', 0.3)    # Minimum safe distance in meters
        self.declare_parameter('warning_distance', 0.5)     # Warning distance in meters
        self.declare_parameter('sector_count', 5)           # Number of sectors to divide LiDAR scan
        self.declare_parameter('detection_angle', 180.0)    # Angle range to check (degrees)
        self.declare_parameter('direction_change_interval', 5.0)  # seconds
        self.declare_parameter('default_speed', 20)         # Default speed value
        
        self.min_safe_distance = self.get_parameter('min_safe_distance').value
        self.warning_distance = self.get_parameter('warning_distance').value
        self.sector_count = self.get_parameter('sector_count').value
        self.detection_angle = self.get_parameter('detection_angle').value
        self.direction_change_interval = self.get_parameter('direction_change_interval').value
        self.default_speed = self.get_parameter('default_speed').value
        
        # Publishers
        self.right_wheel_pub = self.create_publisher(Float32, 'right_wheel_speed', 10)
        self.left_wheel_pub = self.create_publisher(Float32, 'left_wheel_speed', 10)
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        self.mode_pub = self.create_publisher(String, 'current_mode', 10)
        
        # Subscribers
        self.lidar_subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.lidar_callback,
            10
        )
        
        # Subscribe to gamepad input
        self.gamepad_subscription = self.create_subscription(
            Twist,
            'cmd_vel',  # From gamepad controller
            self.gamepad_callback,
            10
        )
        
        # Obstacle detection state
        self.obstacle_detected = False
        self.obstacle_directions = [False] * self.sector_count
        self.closest_distance = float('inf')
        self.lidar_data_valid = False
        
        # Movement state
        self.current_direction = 0  # 0: forward, 1: turn right, 2: turn left, 3: backward
        self.stuck_time = 0.0
        self.last_direction_change = time.time()
        
        # Speed settings
        self.speed = self.default_speed
        self.lambat = self.speed / 4
        self.serong = self.speed / 3
        self.stop = 0
        
        # Motor state
        self.running = True
        self.current_speed_rwheel = self.stop
        self.current_speed_lwheel = self.stop
        
        # Gamepad state
        self.latest_gamepad_cmd = Twist()
        self.last_gamepad_time = time.time()
        
        # Direct motor control
        self.motor1 = None
        self.motor2 = None
        self.connect_motors()
        
        # Create timers
        self.timer = self.create_timer(1.0/self.update_rate, self.update_callback)
        self.direction_timer = self.create_timer(self.direction_change_interval, self.choose_new_direction)
        self.mode_timer = self.create_timer(0.5, self.publish_mode)
        
        # Setup keyboard input thread for mode switching
        self.keyboard_thread = threading.Thread(target=self.keyboard_listener)
        self.keyboard_thread.daemon = True
        self.keyboard_thread.start()
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
        
        self.get_logger().info("Mode switcher initialized - Starting in IDLE mode")
        self.get_logger().info("Press 'm' for MANUAL mode, 'a' for AUTONOMOUS mode, 'i' for IDLE mode")
    
    def keyboard_listener(self):
        """Thread function to listen for keyboard input for mode switching"""
        self.get_logger().info("Keyboard listener started - waiting for commands")
        
        while rclpy.ok() and self.running:
            # Check if there's input available (non-blocking)
            r, _, _ = select.select([sys.stdin], [], [], 0.1)
            
            if r:
                key = sys.stdin.readline().strip().lower()
                
                if key == 'm':
                    self.set_mode(self.MANUAL_MODE)
                elif key == 'a':
                    self.set_mode(self.AUTO_MODE)
                elif key == 'i':
                    self.set_mode(self.IDLE_MODE)
                elif key == 'q':
                    self.get_logger().info("Quit command received")
                    self.signal_handler(None, None)
                    break
    
    def set_mode(self, new_mode):
        """Change the operating mode"""
        if new_mode == self.current_mode:
            return
            
        self.get_logger().info(f"Switching from {self.current_mode} to {new_mode} mode")
        self.current_mode = new_mode
        
        # Stop motors when mode changes
        if new_mode == self.IDLE_MODE:
            self.stop_motors()
        
        # Publish the new mode
        self.publish_mode()
    
    def publish_mode(self):
        """Publish the current mode for monitoring"""
        msg = String()
        msg.data = self.current_mode
        self.mode_pub.publish(msg)
    
    def stop_motors(self):
        """Stop all motor movement"""
        self.current_speed_rwheel = 0
        self.current_speed_lwheel = 0
        self.publish_wheel_speeds()
        
        if self.motor1:
            self.safe_send_rpm(self.motor1, 1, 0)
        if self.motor2:
            self.safe_send_rpm(self.motor2, 1, 0)
    
    def signal_handler(self, sig, frame):
        """Handle shutdown signals"""
        self.get_logger().info("Shutdown signal received, cleaning up...")
        self.running = False
        self.stop_motors()
        time.sleep(0.5)  # Give time for stop commands to be sent
        rclpy.shutdown()
    
    def verify_port_exists(self, port):
        return os.path.exists(port)
    
    def connect_motors(self):
        if MotorControl is None:
            self.get_logger().warn("Running in simulation mode - no direct motor control")
            return
        
        if self.verify_port_exists(self.r_wheel_port):
            try:
                self.motor1 = MotorControl(device=self.r_wheel_port)
                self.motor1.set_drive_mode(1, 2)
                self.get_logger().info(f"Right motor connected to {self.r_wheel_port}")
            except Exception as e:
                self.get_logger().error(f"Right motor error: {e}")
                self.motor1 = None
        
        if self.verify_port_exists(self.l_wheel_port):
            try:
                self.motor2 = MotorControl(device=self.l_wheel_port)
                self.motor2.set_drive_mode(1, 2)
                self.get_logger().info(f"Left motor connected to {self.l_wheel_port}")
            except Exception as e:
                self.get_logger().error(f"Left motor error: {e}")
                self.motor2 = None
    
    def safe_send_rpm(self, motor_obj, motor_id, speed):
        if not motor_obj:
            return False
        
        try:
            motor_obj.send_rpm(motor_id, speed)
            return True
        except Exception as e:
            self.get_logger().error(f"Error sending RPM: {e}")
            return False
    
    def gamepad_callback(self, msg):
        """Process gamepad command"""
        self.latest_gamepad_cmd = msg
        self.last_gamepad_time = time.time()
    
    def lidar_callback(self, msg):
        """Process LiDAR data and detect obstacles"""
        if not self.running:
            return
        
        # Set LiDAR as valid
        self.lidar_data_valid = True
        
        # Find minimum distance
        ranges = list(msg.ranges)
        
        # Remove invalid measurements (often returned as 0.0, inf, or nan)
        filtered_ranges = [r for r in ranges if r > 0.1 and r < 10.0 and not math.isnan(r) and not math.isinf(r)]
        
        if not filtered_ranges:
            self.get_logger().warn("No valid LiDAR readings received")
            self.obstacle_detected = False
            self.closest_distance = float('inf')
            return
        
        # Get min distance from valid readings
        self.closest_distance = min(filtered_ranges)
        
        # Determine if there's an obstacle
        self.obstacle_detected = self.closest_distance < self.warning_distance
        
        # Calculate the range of indices that correspond to our detection angle
        angle_increment = msg.angle_increment
        mid_index = len(ranges) // 2
        angle_range = int((self.detection_angle * math.pi / 180.0) / angle_increment / 2)
        start_index = max(0, mid_index - angle_range)
        end_index = min(len(ranges) - 1, mid_index + angle_range)
        
        # Divide the scan into sectors
        sector_size = (end_index - start_index) // self.sector_count
        self.obstacle_directions = [False] * self.sector_count
        
        for i in range(self.sector_count):
            sector_start = start_index + i * sector_size
            sector_end = end_index if i == self.sector_count - 1 else sector_start + sector_size
            
            sector_ranges = [r for r in ranges[sector_start:sector_end] 
                            if r > 0.1 and r < 10.0 and not math.isnan(r) and not math.isinf(r)]
            
            if sector_ranges and min(sector_ranges) < self.warning_distance:
                self.obstacle_directions[i] = True
    
    def publish_wheel_speeds(self):
        """Publish wheel speeds to ROS topics"""
        if not self.running:
            return
        
        # Publish motor speeds to ROS topics
        right_msg = Float32()
        right_msg.data = float(self.current_speed_rwheel)
        self.right_wheel_pub.publish(right_msg)
        
        left_msg = Float32()
        left_msg.data = float(self.current_speed_lwheel)
        self.left_wheel_pub.publish(left_msg)
        
        # Also publish as cmd_vel for compatibility with other nodes
        twist_msg = Twist()
        avg_speed = (abs(self.current_speed_rwheel) + abs(self.current_speed_lwheel)) / 2.0
        
        linear_x = 0.0
        angular_z = 0.0
        
        if self.current_speed_rwheel < 0 and self.current_speed_lwheel > 0:
            # Forward
            linear_x = avg_speed / 100.0  # Scale to m/s
        elif self.current_speed_rwheel > 0 and self.current_speed_lwheel < 0:
            # Backward
            linear_x = -avg_speed / 100.0  # Scale to m/s
        
        if (self.current_speed_rwheel < 0 and self.current_speed_lwheel < 0) or \
           (self.current_speed_rwheel > 0 and self.current_speed_lwheel > 0):
            # Rotation
            angular_z = (self.current_speed_rwheel) / 100.0  # Scale to rad/s
        
        twist_msg.linear.x = linear_x
        twist_msg.angular.z = angular_z
        
        self.cmd_vel_pub.publish(twist_msg)
    
    def choose_new_direction(self):
        """Choose a new movement direction periodically if in autonomous mode and not handling obstacles"""
        if not self.running or self.current_mode != self.AUTO_MODE or self.obstacle_detected:
            return
        
        # Save previous direction
        prev_direction = self.current_direction
        
        # Choose a new direction (biased toward forward movement)
        choices = [0, 0, 0, 0, 1, 2, 3]  # Forward has higher probability
        
        while self.current_direction == prev_direction:
            self.current_direction = random.choice(choices)
        
        direction_names = ["FORWARD", "RIGHT", "LEFT", "BACKWARD"]
        self.get_logger().info(f"Changing direction to {direction_names[self.current_direction]}")
    
    def process_scan(self, scan_msg):
        """Process scan data and calculate obstacle avoidance command for autonomous mode"""
        cmd_vel = Twist()
        
        # Calculate indices for the detection angle range
        angle_increment = scan_msg.angle_increment
        mid_index = len(scan_msg.ranges) // 2
        angle_range = int((self.detection_angle * math.pi / 180.0) / angle_increment / 2)
        start_index = max(0, mid_index - angle_range)
        end_index = min(len(scan_msg.ranges) - 1, mid_index + angle_range)
        
        # Divide the scan range into sectors
        sectors = [[] for _ in range(self.sector_count)]
        sector_size = (end_index - start_index) // self.sector_count
        
        for i in range(self.sector_count):
            sector_start = start_index + i * sector_size
            sector_end = end_index if i == self.sector_count - 1 else sector_start + sector_size
            
            for j in range(sector_start, sector_end):
                if j < len(scan_msg.ranges):
                    range_val = scan_msg.ranges[j]
                    # Filter out invalid readings
                    if scan_msg.range_min < range_val < scan_msg.range_max and not math.isinf(range_val) and not math.isnan(range_val):
                        sectors[i].append(range_val)
        
        # Find minimum distance in each sector
        min_distances = [float('inf')] * self.sector_count
        obstacle_detected = False
        
        for i in range(self.sector_count):
            if sectors[i]:
                min_distances[i] = min(sectors[i])
                if min_distances[i] < self.min_safe_distance:
                    obstacle_detected = True
        
        # Set up RPM values for wheel control
        rwheel = self.stop
        lwheel = self.stop
        
        # Main obstacle avoidance algorithm
        if obstacle_detected:
            # Find the sector with the most space (maximum distance)
            best_sector = 0
            max_distance = 0.0
            
            for i in range(self.sector_count):
                if sectors[i] and min_distances[i] > max_distance:
                    max_distance = min_distances[i]
                    best_sector = i
            
            # Calculate the heading to the best sector
            sector_diff = best_sector - (self.sector_count // 2)
            
            # Front obstacle (sector in the middle)
            if self.obstacle_directions[self.sector_count // 2]:
                # Can't go forward, try to turn
                if sector_diff < 0:  # Best sector is on the left
                    self.get_logger().info("Obstacle in front, turning left")
                    rwheel = -self.lambat
                    lwheel = -self.lambat  # Turn left
                else:  # Best sector is on the right
                    self.get_logger().info("Obstacle in front, turning right")
                    rwheel = self.lambat
                    lwheel = self.lambat  # Turn right
            else:
                # No direct front obstacle, adjust trajectory toward best sector
                if sector_diff < 0:  # Best sector is on the left
                    rwheel = -self.speed * 0.8
                    lwheel = self.speed  # Turn slightly left while moving
                elif sector_diff > 0:  # Best sector is on the right
                    rwheel = -self.speed
                    lwheel = self.speed * 0.8  # Turn slightly right while moving
                else:  # Best sector is straight ahead
                    rwheel = -self.speed
                    lwheel = self.speed  # Move forward
            
            # Emergency stop if very close obstacle
            min_front_distance = min_distances[self.sector_count // 2]
            if min_front_distance < self.min_safe_distance * 0.5:
                # Reverse to avoid collision
                rwheel = self.speed
                lwheel = -self.speed
                self.get_logger().warn(f"Emergency stop! Obstacle at {min_front_distance:.2f}m")
        else:
            # No obstacles, use normal movement based on current direction
            rwheel, lwheel = self.get_movement_commands()
        
        return rwheel, lwheel
    
    def handle_obstacle_avoidance(self):
        """Determine the best movement to avoid obstacles"""
        if not self.lidar_data_valid:
            # No LiDAR data, continue with current movement
            return self.get_movement_commands()
        
        # Emergency stop if very close obstacle
        if self.closest_distance < self.min_safe_distance:
            self.get_logger().warn(f"Emergency stop: obstacle at {self.closest_distance:.2f}m")
            # Briefly reverse before choosing a new direction
            return self.speed, -self.speed  # Reverse
        
        # If no obstacles, continue with normal movement
        if not self.obstacle_detected:
            # Reset stuck timer
            self.stuck_time = 0.0
            return self.get_movement_commands()
        
        # Obstacle avoidance logic based on sector information
        # Front obstacle (sector 0)
        if self.obstacle_directions[0]:
            # Can't go forward, try to turn
            if not self.obstacle_directions[4]:  # Left is clear
                self.get_logger().info("Obstacle in front, turning left")
                return -self.lambat, -self.lambat  # Turn left
            elif not self.obstacle_directions[1]:  # Right is clear
                self.get_logger().info("Obstacle in front, turning right")
                return self.lambat, self.lambat  # Turn right
            else:
                # Both sides blocked, try to reverse
                self.get_logger().info("Front and sides blocked, reversing")
                return self.speed, -self.speed  # Reverse
        
        # Right obstacle (sector 1)
        elif self.obstacle_directions[1] and self.current_direction == 1:
            # Obstacle on right and trying to turn right, turn left instead
            self.get_logger().info("Obstacle on right, turning left instead")
            return -self.lambat, -self.lambat  # Turn left
        
        # Left obstacle (sector 4)
        elif self.obstacle_directions[4] and self.current_direction == 2:
            # Obstacle on left and trying to turn left, turn right instead
            self.get_logger().info("Obstacle on left, turning right instead")
            return self.lambat, self.lambat  # Turn right
        
        # Default: continue with planned movement
        return self.get_movement_commands()
    
    def get_movement_commands(self):
        """Generate wheel commands based on current direction"""
        rwheel = self.stop
        lwheel = self.stop
        
        if self.current_direction == 0:  # Forward
            rwheel = -self.speed
            lwheel = self.speed
        elif self.current_direction == 1:  # Turn right
            rwheel = self.lambat
            lwheel = self.lambat 
        elif self.current_direction == 2:  # Turn left
            rwheel = -self.lambat
            lwheel = -self.lambat
        elif self.current_direction == 3:  # Backward
            rwheel = self.speed
            lwheel = -self.speed
        
        return rwheel, lwheel
    
    def process_gamepad_twist(self, twist_msg):
        """Convert gamepad Twist message to wheel velocities"""
        # Simple differential drive conversion
        linear_x = twist_msg.linear.x * self.speed  # Scale by max speed
        angular_z = twist_msg.angular.z * self.speed
        
        # Convert to wheel velocities
        right_wheel = linear_x - angular_z
        left_wheel = linear_x + angular_z
        
        # Scale to motor command range and reverse direction as needed for your motors
        # (Adjust these based on your motor control needs)
        rwheel = -right_wheel  # Negative because of motor orientation
        lwheel = left_wheel
        
        return rwheel, lwheel
    
    def check_stuck_condition(self):
        """Check if robot is stuck and force a direction change if needed"""
        if self.current_mode != self.AUTO_MODE:
            return False
            
        now = time.time()
        
        # If we've been avoiding the same obstacle for too long, force a change
        if self.obstacle_detected and now - self.last_direction_change > 5.0:
            self.stuck_time += 1.0/self.update_rate
            
            if self.stuck_time > 3.0:  # Stuck for 3 seconds
                # Force a random direction change
                self.current_direction = random.randint(0, 3)
                self.last_direction_change = now
                self.stuck_time = 0.0
                self.get_logger().warn(f"Robot appears stuck! Forcing new direction: {self.current_direction}")
                return True
        else:
            self.stuck_time = 0.0
            
        return False
    
    def update_callback(self):
        """Main control loop"""
        if not self.running:
            return
            
        try:
            # Handle different modes
            if self.current_mode == self.IDLE_MODE:
                # In idle mode, stop motors
                self.current_speed_rwheel = self.stop
                self.current_speed_lwheel = self.stop
                
            elif self.current_mode == self.MANUAL_MODE:
                # In manual mode, process gamepad commands
                self.current_speed_rwheel, self.current_speed_lwheel = self.process_gamepad_twist(self.latest_gamepad_cmd)
                
                # Check for gamepad timeout - if no commands for a while, stop
                if time.time() - self.last_gamepad_time > 1.0:  # 1 second timeout
                    self.current_speed_rwheel = self.stop
                    self.current_speed_lwheel = self.stop
                
            elif self.current_mode == self.AUTO_MODE:
                # In autonomous mode, use LiDAR-based navigation
                # Check for stuck condition
                self.check_stuck_condition()
                
                # Get wheel commands based on obstacle avoidance from the latest LiDAR data
                if self.lidar_data_valid:
                    self.current_speed_rwheel, self.current_speed_lwheel = self.process_scan(self.latest_scan)
                else:
                    self.current_speed_rwheel, self.current_speed_lwheel = self.get_movement_commands()
            
            # Publish to ROS 2 topics
            self.publish_wheel_speeds()
            
            # Also send direct commands if motors are connected
            self.safe_send_rpm(self.motor1, 1, self.current_speed_rwheel)
            self.safe_send_rpm(self.motor2, 1, self.current_speed_lwheel)
            
        except Exception as e:
            self.get_logger().error(f"Update error: {e}")
    
    def cleanup(self):
        """Clean up resources and stop motors"""
        self.get_logger().info("Cleaning up and stopping motors...")
        try:
            self.running = False
            
            if self.motor1:
                try:
                    self.motor1.send_rpm(1, 0)
                    self.motor1.close()
                except Exception as e:
                    self.get_logger().error(f"Error closing motor1: {e}")
            
            if self.motor2:
                try:
                    self.motor2.send_rpm(1, 0)
                    self.motor2.close()
                except Exception as e:
                    self.get_logger().error(f"Error closing motor2: {e}")
                    
        except Exception as e:
            self.get_logger().error(f"Error during cleanup: {e}")


def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = ModeSwitcherNode()
        
        try:
            rclpy.spin(node)
        except KeyboardInterrupt:
            pass
        finally:
            node.cleanup()
            node.destroy_node()
    
    except Exception as e:
        if rclpy.ok():
            print(f"Error in main: {e}")
    
    finally:
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
