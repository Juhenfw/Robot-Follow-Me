#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
import numpy as np
import math
import time
import os
from gpiozero import LED  # Ganti dengan gpiozero untuk kontrol LED
from robot_control_system.ddsm115 import MotorControl

class RobotAutonomousNavigation(Node):
    def __init__(self):
        super().__init__('robot_autonomous_navigation')
        
        # Inisialisasi GPIO untuk LED pada pin 17 menggunakan gpiozero
        self.led = LED(17)  # Pin GPIO untuk LED
        self.led.on()  # Menyalakan LED saat program dijalankan

        # Port untuk motor kiri dan kanan
        self.r_wheel_port = "/dev/ttyRS485-1"
        self.l_wheel_port = "/dev/ttyRS485-2"
        
        # Parameter kecepatan
        self.max_speed = 70
        self.normal_speed = self.max_speed * 0.7  # 70% dari kecepatan maksimum
        self.slow_speed = self.max_speed * 0.4    # 40% dari kecepatan maksimum
        self.turn_speed = self.max_speed * 0.6    # 60% dari kecepatan maksimum
        
        # Dimensi robot dan posisi sensor
        self.robot_width = 0.30  # 30 cm dalam meter
        self.robot_length = 0.60  # 60 cm dalam meter
        self.lidar_position_x = 0.05  # 5 cm dari depan robot (asumsi)
        self.lidar_to_front = self.lidar_position_x  # Jarak dari LiDAR ke depan robot
        self.lidar_to_back = self.robot_length - self.lidar_position_x  # Jarak dari LiDAR ke belakang robot
        self.lidar_to_side = self.robot_width / 2.0  # Jarak dari LiDAR ke sisi robot (asumsi LiDAR di tengah)
        
        # Parameter blind spot - daerah yang tidak terlihat oleh LiDAR
        self.has_rear_blind_spot = True  # LiDAR tidak melihat ke belakang
        self.rear_safety_factor = 1.5  # Faktor pengaman untuk belakang robot
        
        # Inisialisasi state motor
        self.left_wheel_speed = 0
        self.right_wheel_speed = 0
        
        # Inisialisasi motor controller
        self.motor_kiri = None
        self.motor_kanan = None
        self.connect_motors()
        
        # Parameter untuk deteksi obstacle
        self.declare_parameter('safety_distance', 0.4)       # jarak aman (meter)
        self.declare_parameter('danger_distance', 0.25)       # jarak bahaya (meter)
        self.declare_parameter('critical_distance', 0.2)     # jarak kritis (meter)
        self.declare_parameter('scan_angle_front', 120)      # area scan depan (derajat)
        self.declare_parameter('scan_angle_side', 60)        # area scan samping (derajat)
        self.declare_parameter('navigation_strategy', 'dynamic_window') # strategi navigasi
        
        # Ambil nilai parameter
        self.safety_distance = self.get_parameter('safety_distance').get_parameter_value().double_value
        self.danger_distance = self.get_parameter('danger_distance').get_parameter_value().double_value
        self.critical_distance = self.get_parameter('critical_distance').get_parameter_value().double_value
        self.scan_angle_front = self.get_parameter('scan_angle_front').get_parameter_value().integer_value
        self.scan_angle_side = self.get_parameter('scan_angle_side').get_parameter_value().integer_value
        self.navigation_strategy = self.get_parameter('navigation_strategy').get_parameter_value().string_value
        
        # Publisher
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        self.status_pub = self.create_publisher(String, 'robot/status', 10)
        
        # Subscriber
        self.scan_sub = self.create_subscription(
            LaserScan, 'scan', self.scan_callback, 10)
        self.shutdown_sub = self.create_subscription(
            String, '/system/shutdown', self.shutdown_callback, 10)
        
        # Timer untuk kontrol navigasi
        self.timer = self.create_timer(0.1, self.navigation_loop)
        
        # State navigasi
        self.latest_scan = None
        self.obstacles = {
            'front': False,
            'front_left': False,
            'front_right': False,
            'left': False,
            'right': False,
            'rear': self.has_rear_blind_spot,  # Selalu anggap ada obstacle di belakang jika blind spot
            'rear_left': False,
            'rear_right': False
        }
        self.min_distances = {
            'front': float('inf'),
            'front_left': float('inf'),
            'front_right': float('inf'),
            'left': float('inf'),
            'right': float('inf'),
            'rear': 0.0 if self.has_rear_blind_spot else float('inf'),  # Jarak 0 jika blind spot
            'rear_left': float('inf'),
            'rear_right': float('inf')
        }
        
        # State untuk perilaku navigasi
        self.current_behavior = 'exploring'  # ['exploring', 'avoiding', 'escaping', 'careful_maneuvering']
        self.avoid_direction = 1  # 1 = kiri, -1 = kanan
        self.last_direction_change = time.time()
        self.stuck_count = 0
        self.last_position = None
        self.random_direction_timer = 0
        
        # Parameter untuk manuver mundur yang hati-hati
        self.reverse_maneuver_state = 0  # 0=belum mulai, 1=manuver mundur, 2=rotasi
        self.reverse_maneuver_timer = 0
        self.reverse_maneuver_direction = 1  # 1=kiri, -1=kanan
        
        # Data tambahan untuk navigasi
        self.exploration_target = None  # [distance, angle]
        self.obstacle_memory = []  # Mengingat obstacle terakhir yang ditemui
        
        self.get_logger().info('Robot Autonomous Navigation System diinisialisasi')
        self.get_logger().info(f'Dimensi robot: {self.robot_width}m x {self.robot_length}m')
        self.get_logger().info(f'Jarak aman: {self.safety_distance}m, Jarak bahaya: {self.danger_distance}m')
        self.get_logger().info(f'Strategi navigasi: {self.navigation_strategy}')
    
    def verify_port_exists(self, port):
        """Verifikasi keberadaan port untuk motor"""
        return os.path.exists(port)
    
    def connect_motors(self):
        """Menghubungkan ke motor DDSM115"""
        self.get_logger().info('Menghubungkan ke motor DDSM115...')
        
        # Hubungkan motor kanan
        if self.verify_port_exists(self.r_wheel_port):
            try:
                self.motor_kanan = MotorControl(device=self.r_wheel_port)
                self.motor_kanan.set_drive_mode(1, 2)
                self.get_logger().info('Motor kanan terhubung')
            except Exception as e:
                self.get_logger().error(f'Error terhubung ke motor kanan: {e}')
                self.motor_kanan = None
        else:
            self.get_logger().error(f'Port {self.r_wheel_port} tidak ditemukan')
        
        # Hubungkan motor kiri
        if self.verify_port_exists(self.l_wheel_port):
            try:
                self.motor_kiri = MotorControl(device=self.l_wheel_port)
                self.motor_kiri.set_drive_mode(1, 2)
                self.get_logger().info('Motor kiri terhubung')
            except Exception as e:
                self.get_logger().error(f'Error terhubung ke motor kiri: {e}')
                self.motor_kiri = None
        else:
            self.get_logger().error(f'Port {self.l_wheel_port} tidak ditemukan')
    
    def safe_send_rpm(self, motor_obj, motor_id, speed):
        """Kirim perintah RPM dengan penanganan error"""
        if not motor_obj:
            return False
        
        try:
            motor_obj.send_rpm(motor_id, speed)
            return True
        except Exception as e:
            self.get_logger().error(f'Error mengirim RPM: {e}')
            return False
    
    def scan_callback(self, msg):
        """Proses data LiDAR untuk deteksi obstacle dengan pertimbangan ukuran robot"""
        self.latest_scan = msg
        
        if not msg.ranges:
            return
        
        # Konversi data scan ke array numpy
        ranges = np.array(msg.ranges)
        angles = np.linspace(msg.angle_min, msg.angle_max, len(ranges))
        
        # Filter data yang tidak valid
        valid_indices = np.where(~np.isnan(ranges) & ~np.isinf(ranges) & (ranges > 0.1))[0]
        if len(valid_indices) == 0:
            return
        
        valid_ranges = ranges[valid_indices]
        valid_angles = angles[valid_indices]
        
        # Reset status obstacle (kecuali belakang jika blind spot)
        for key in self.obstacles:
            if key != 'rear' or not self.has_rear_blind_spot:
                self.obstacles[key] = False
                self.min_distances[key] = float('inf')
        
        # Definisi sektor-sektor untuk deteksi (semua dalam radian)
        half_front = math.radians(self.scan_angle_front / 2)
        half_side = math.radians(self.scan_angle_side / 2)
        
        # Sektor depan (misalnya -60° sampai +60°)
        front_indices = np.where((valid_angles >= -half_front) & (valid_angles <= half_front))[0]
        if len(front_indices) > 0:
            # Koreksi jarak untuk dimensi robot (kurangi jarak dengan jarak LiDAR ke depan robot)
            front_ranges = valid_ranges[front_indices] - self.lidar_to_front
            self.min_distances['front'] = max(0.01, np.min(front_ranges))  # Minimal 1cm untuk menghindari 0
            self.obstacles['front'] = self.min_distances['front'] < self.safety_distance
        
        # Sektor depan-kiri
        front_left_indices = np.where((valid_angles >= -math.radians(120)) & (valid_angles < -half_front))[0]
        if len(front_left_indices) > 0:
            # Koreksi jarak berdasarkan sudut (proyeksi ke samping dan depan)
            front_left_ranges = valid_ranges[front_left_indices]
            front_left_angles = valid_angles[front_left_indices]
            
            # Perkiraan koreksi jarak berdasarkan sudut dan dimensi robot
            corrected_ranges = []
            for i, angle in enumerate(front_left_angles):
                # Proyeksikan jarak terhadap sudut untuk memperhitungkan dimensi robot
                angle_abs = abs(angle)
                if angle_abs < math.pi/4:  # 0-45 derajat, lebih ke depan
                    correction = self.lidar_to_front
                elif angle_abs > math.pi*3/4:  # 135-180 derajat, lebih ke belakang
                    correction = self.lidar_to_side
                else:  # 45-135 derajat, di samping
                    correction = self.lidar_to_side * math.sin(angle_abs) + self.lidar_to_front * math.cos(angle_abs)
                
                corrected_range = max(0.01, front_left_ranges[i] - correction)
                corrected_ranges.append(corrected_range)
            
            self.min_distances['front_left'] = min(corrected_ranges)
            self.obstacles['front_left'] = self.min_distances['front_left'] < self.safety_distance
        
        # Sektor depan-kanan
        front_right_indices = np.where((valid_angles > half_front) & (valid_angles <= math.radians(120)))[0]
        if len(front_right_indices) > 0:
            # Koreksi sama seperti front_left
            front_right_ranges = valid_ranges[front_right_indices]
            front_right_angles = valid_angles[front_right_indices]
            
            corrected_ranges = []
            for i, angle in enumerate(front_right_angles):
                angle_abs = abs(angle)
                if angle_abs < math.pi/4:  # 0-45 derajat, lebih ke depan
                    correction = self.lidar_to_front
                elif angle_abs > math.pi*3/4:  # 135-180 derajat, lebih ke belakang
                    correction = self.lidar_to_side
                else:  # 45-135 derajat, di samping
                    correction = self.lidar_to_side * math.sin(angle_abs) + self.lidar_to_front * math.cos(angle_abs)
                
                corrected_range = max(0.01, front_right_ranges[i] - correction)
                corrected_ranges.append(corrected_range)
            
            self.min_distances['front_right'] = min(corrected_ranges)
            self.obstacles['front_right'] = self.min_distances['front_right'] < self.safety_distance
        
        # Sektor kiri
        left_indices = np.where((valid_angles >= -math.pi) & (valid_angles < -math.radians(120)))[0]
        if len(left_indices) > 0:
            # Koreksi untuk dimensi robot (samping)
            left_ranges = valid_ranges[left_indices] - self.lidar_to_side
            self.min_distances['left'] = max(0.01, np.min(left_ranges))
            self.obstacles['left'] = self.min_distances['left'] < self.safety_distance
        
        # Sektor kanan
        right_indices = np.where((valid_angles > math.radians(120)) & (valid_angles <= math.pi))[0]
        if len(right_indices) > 0:
            # Koreksi untuk dimensi robot (samping)
            right_ranges = valid_ranges[right_indices] - self.lidar_to_side
            self.min_distances['right'] = max(0.01, np.min(right_ranges))
            self.obstacles['right'] = self.min_distances['right'] < self.safety_distance
        
        # Jika LiDAR dapat melihat ke belakang (meskipun sebagian), tambahkan deteksi belakang
        if not self.has_rear_blind_spot:
            # Definisikan sektor belakang
            rear_indices = np.where((valid_angles >= math.radians(150)) | (valid_angles <= -math.radians(150)))[0]
            if len(rear_indices) > 0:
                # Koreksi untuk dimensi robot (belakang)
                rear_ranges = valid_ranges[rear_indices] - self.lidar_to_back
                self.min_distances['rear'] = max(0.01, np.min(rear_ranges))
                self.obstacles['rear'] = self.min_distances['rear'] < (self.safety_distance * self.rear_safety_factor)
        else:
            # Jika blind spot, selalu anggap ada obstacle dengan jarak aman
            self.min_distances['rear'] = self.danger_distance * 0.5  # Setengah jarak bahaya
            self.obstacles['rear'] = True
        
        # Cek jika terjebak (semua sektor terhalang)
        if (self.obstacles['front'] and self.obstacles['front_left'] and 
            self.obstacles['front_right'] and self.obstacles['left'] and 
            self.obstacles['right']):
            self.stuck_count += 1
        else:
            self.stuck_count = max(0, self.stuck_count - 1)
    
    def shutdown_callback(self, msg):
        """Handle permintaan shutdown"""
        if msg.data == "shutdown":
            self.get_logger().warn('Perintah shutdown diterima, menghentikan motor')
            self.stop_motors()
    
    def stop_motors(self):
        """Hentikan semua motor"""
        self.get_logger().info('Menghentikan motor')
        self.safe_send_rpm(self.motor_kanan, 1, 0)
        self.safe_send_rpm(self.motor_kiri, 1, 0)
        
        # Juga kirim perintah stop ke ROS
        cmd = Twist()
        self.cmd_vel_pub.publish(cmd)
    
    def set_motor_speeds(self, left_speed, right_speed):
        """Atur kecepatan motor dengan batasan"""
        # Terapkan batasan kecepatan (-max_speed sampai +max_speed)
        left_speed = max(-self.max_speed, min(self.max_speed, left_speed))
        right_speed = max(-self.max_speed, min(self.max_speed, right_speed))
        
        # Update state kecepatan
        self.left_wheel_speed = left_speed
        self.right_wheel_speed = right_speed
        
        # Kirim perintah ke motor
        self.safe_send_rpm(self.motor_kiri, 1, left_speed)
        self.safe_send_rpm(self.motor_kanan, 1, right_speed)
        
        # Log kecepatan (hanya untuk debugging)
        # self.get_logger().debug(f'Kecepatan: Kiri={left_speed}, Kanan={right_speed}')
    
    def find_safe_direction(self):
        """Temukan arah yang paling aman untuk bergerak"""
        # Cek semua arah dan berikan skor keamanan
        directions = {
            'front': (not self.obstacles['front'], self.min_distances['front']),
            'front_left': (not self.obstacles['front_left'], self.min_distances['front_left']),
            'front_right': (not self.obstacles['front_right'], self.min_distances['front_right']),
            'left': (not self.obstacles['left'], self.min_distances['left']),
            'right': (not self.obstacles['right'], self.min_distances['right']),
            # Jangan pertimbangkan belakang kecuali dalam keadaan terpaksa
        }
        
        # Urutkan berdasarkan keamanan (tidak ada obstacle) dan jarak
        safe_directions = sorted(
            directions.items(),
            key=lambda x: (x[1][0], x[1][1]),  # Pertama tidak ada obstacle, kemudian jarak terbesar
            reverse=True  # Urutkan dari paling aman ke kurang aman
        )
        
        # Jika tidak ada arah yang aman, cek apakah arah belakang aman
        if not safe_directions[0][1][0] and not self.has_rear_blind_spot and not self.obstacles['rear']:
            return 'rear'
        
        return safe_directions[0][0] if safe_directions else 'none'
    
    def navigation_loop(self):
        """Algoritma navigasi utama robot"""
        if not self.latest_scan:
            self.get_logger().warn('Belum ada data scan, menunggu...')
            return
        
        # Publish status navigasi
        status_msg = String()
        status_msg.data = f"mode:autonomous;behavior:{self.current_behavior};obstacles:" + \
                          f"front:{self.obstacles['front']},left:{self.obstacles['left']}," + \
                          f"right:{self.obstacles['right']},rear:{self.obstacles['rear']};distances:" + \
                          f"front:{self.min_distances['front']:.2f},left:{self.min_distances['left']:.2f}," + \
                          f"right:{self.min_distances['right']:.2f}"
        self.status_pub.publish(status_msg)
        
        # Cek situasi terjebak
        if self.stuck_count > 10:
            self.get_logger().warn('Terdeteksi terjebak! Mencoba melarikan diri...')
            self.current_behavior = 'escaping'
        
        # Handle berbagai mode perilaku
        if self.current_behavior == 'escaping':
            self.execute_escape_behavior()
        elif self.current_behavior == 'avoiding':
            self.execute_avoidance_behavior()
        elif self.current_behavior == 'careful_maneuvering':
            self.execute_careful_maneuver()
        else:  # 'exploring'
            self.execute_exploration_behavior()
    
    def execute_escape_behavior(self):
        """Eksekusi perilaku melarikan diri dari situasi terjebak
           dengan memperhatikan blind spot di belakang robot"""
        
        # Cari arah yang paling aman
        best_direction = self.find_safe_direction()
        
        if best_direction == 'none':
            # Semua arah terhalang, coba rotasi di tempat
            self.get_logger().warn('Semua arah terhalang! Rotasi untuk mencari jalan keluar')
            # Rotasi searah jarum jam (kiri)
            self.set_motor_speeds(-self.turn_speed, -self.turn_speed)  # KIRI: L-, R-
        
        elif best_direction == 'front':
            # Depan aman, bergerak maju perlahan
            self.get_logger().info('Melarikan diri: maju perlahan')
            self.set_motor_speeds(self.slow_speed, -self.slow_speed)  # MAJU: L+, R-
        
        elif best_direction == 'front_left':
            # Depan-kiri aman, belok ke kiri
            self.get_logger().info('Melarikan diri: belok kiri')
            self.set_motor_speeds(-self.turn_speed, -self.normal_speed)  # KIRI dengan variasi: L-, R-
        
        elif best_direction == 'front_right':
            # Depan-kanan aman, belok ke kanan
            self.get_logger().info('Melarikan diri: belok kanan')
            self.set_motor_speeds(self.normal_speed, self.turn_speed)  # KANAN dengan variasi: L+, R+
        
        elif best_direction == 'left':
            # Kiri aman, putar kiri tajam
            self.get_logger().info('Melarikan diri: putar kiri tajam')
            self.set_motor_speeds(-self.turn_speed, -self.turn_speed)  # KIRI: L-, R-
        
        elif best_direction == 'right':
            # Kanan aman, putar kanan tajam
            self.get_logger().info('Melarikan diri: putar kanan tajam')
            self.set_motor_speeds(self.turn_speed, self.turn_speed)  # KANAN: L+, R+
        
        elif best_direction == 'rear' and not self.has_rear_blind_spot:
            # Belakang aman (dan kita bisa melihat ke belakang), beralih ke manuver mundur hati-hati
            self.get_logger().info('Melarikan diri: beralih ke mode manuver mundur hati-hati')
            self.current_behavior = 'careful_maneuvering'
            self.reverse_maneuver_state = 0
            self.reverse_maneuver_timer = 0
            return
        else:
            # Fallback, rotasi untuk mencari jalan keluar
            self.get_logger().warn('Tidak ada arah yang jelas, rotasi untuk mencari jalan keluar')
            self.set_motor_speeds(-self.turn_speed, -self.turn_speed)  # KIRI: L-, R-
        
        # Reset counter setelah beberapa saat
        self.random_direction_timer += 1
        if self.random_direction_timer > 30:  # Beri waktu lebih lama untuk escape
            self.random_direction_timer = 0
            self.stuck_count = 0
            self.current_behavior = 'exploring'
            self.get_logger().info('Keluar dari mode melarikan diri')
    
    def execute_careful_maneuver(self):
        """Eksekusi manuver mundur dengan hati-hati"""
        # Manuver ini digunakan ketika mundur diperlukan tetapi mungkin ada blind spot
        
        # State machine untuk manuver mundur secara hati-hati
        self.reverse_maneuver_timer += 1
        
        if self.reverse_maneuver_state == 0:
            # Fase inisialisasi - pilih arah rotasi
            self.get_logger().info('Manuver mundur: menentukan arah rotasi')
            if self.min_distances['left'] > self.min_distances['right']:
                self.reverse_maneuver_direction = 1  # Rotasi kiri
            else:
                self.reverse_maneuver_direction = -1  # Rotasi kanan
            self.reverse_maneuver_state = 1
            self.reverse_maneuver_timer = 0
        
        elif self.reverse_maneuver_state == 1:
            # Fase mundur pendek (sangat hati-hati dan sebentar)
            if self.reverse_maneuver_timer < 10:  # 1 detik
                self.get_logger().info('Manuver mundur: mundur perlahan')
                self.set_motor_speeds(-self.slow_speed, self.slow_speed)  # MUNDUR: L-, R+
            else:
                self.reverse_maneuver_state = 2
                self.reverse_maneuver_timer = 0
        
        elif self.reverse_maneuver_state == 2:
            # Fase rotasi untuk menghadap arah baru
            if self.reverse_maneuver_timer < 15:  # 1.5 detik
                self.get_logger().info(f'Manuver mundur: rotasi {("kiri" if self.reverse_maneuver_direction > 0 else "kanan")}')
                if self.reverse_maneuver_direction > 0:
                    self.set_motor_speeds(-self.turn_speed, -self.turn_speed)  # KIRI: L-, R-
                else:
                    self.set_motor_speeds(self.turn_speed, self.turn_speed)  # KANAN: L+, R+
            else:
                # Selesai manuver, kembali ke mode eksplorasi
                self.current_behavior = 'exploring'
                self.get_logger().info('Manuver mundur selesai, kembali ke mode eksplorasi')
    
    def execute_avoidance_behavior(self):
        """Eksekusi perilaku menghindari obstacle dengan mempertimbangkan ukuran robot"""
        # Cek apakah obstacle masih ada
        if not (self.obstacles['front'] or self.obstacles['front_left'] or 
                self.obstacles['front_right']):
            self.current_behavior = 'exploring'
            self.get_logger().info('Kembali ke mode eksplorasi')
            return
        
        # Strategi menghindari obstacle
        if self.obstacles['front']:
            # Obstacle di depan, tentukan arah belok
            if self.min_distances['left'] > self.min_distances['right']:
                # Lebih banyak ruang di kiri, belok kiri
                self.get_logger().info('Menghindari: belok kiri')
                self.set_motor_speeds(-self.slow_speed, -self.turn_speed)  # KIRI dengan variasi: L-, R-
                self.avoid_direction = 1
            else:
                # Lebih banyak ruang di kanan
                self.get_logger().info('Menghindari: belok kanan')
                self.set_motor_speeds(self.turn_speed, self.slow_speed)  # KANAN dengan variasi: L+, R+
                self.avoid_direction = -1
        
        elif self.obstacles['front_left']:
            # Obstacle di depan-kiri, belok kanan
            self.get_logger().info('Menghindari: depan-kiri terhalang, belok kanan')
            self.set_motor_speeds(self.normal_speed, self.slow_speed)  # KANAN dengan variasi: L+, R+
            self.avoid_direction = -1
        
        elif self.obstacles['front_right']:
            # Obstacle di depan-kanan, belok kiri
            self.get_logger().info('Menghindari: depan-kanan terhalang, belok kiri')
            self.set_motor_speeds(-self.slow_speed, -self.normal_speed)  # KIRI dengan variasi: L-, R-
            self.avoid_direction = 1
        
        else:
            # Tidak ada obstacle langsung di depan, lanjutkan maju
            self.current_behavior = 'exploring'
            self.get_logger().info('Kembali ke mode eksplorasi')
    
    def execute_exploration_behavior(self):
        """Eksekusi perilaku eksplorasi lingkungan dengan mempertimbangkan ukuran robot"""
        # Cek jika ada obstacle di jalur
        if self.obstacles['front'] or self.min_distances['front'] < self.safety_distance:
            self.current_behavior = 'avoiding'
            self.get_logger().info('Obstacle terdeteksi, beralih ke mode menghindari')
            return
        
        # Buat pergerakan eksplorasi yang dinamis
        # Jika ada obstacle di samping, jaga jarak
        if self.obstacles['left'] and not self.obstacles['right']:
            # Obstacle di kiri, bergerak sedikit ke kanan
            self.get_logger().debug('Eksplorasi: jaga jarak dari kiri')
            self.set_motor_speeds(self.normal_speed, -self.slow_speed)  # MAJU dengan kanan lebih lambat: L+, R- (lebih ke kanan)
        
        elif self.obstacles['right'] and not self.obstacles['left']:
            # Obstacle di kanan, bergerak sedikit ke kiri
            self.get_logger().debug('Eksplorasi: jaga jarak dari kanan')
            self.set_motor_speeds(self.slow_speed, -self.normal_speed)  # MAJU dengan kiri lebih lambat: L+, R- (lebih ke kiri)
        
        elif self.obstacles['front_left'] and not self.obstacles['front_right']:
            # Obstacle di depan-kiri, bergerak ke kanan
            self.get_logger().debug('Eksplorasi: hindari depan-kiri')
            self.set_motor_speeds(self.normal_speed, -self.slow_speed)  # MAJU dengan kanan lebih lambat: L+, R- (lebih ke kanan)
        
        elif self.obstacles['front_right'] and not self.obstacles['front_left']:
            # Obstacle di depan-kanan, bergerak ke kiri
            self.get_logger().debug('Eksplorasi: hindari depan-kanan')
            self.set_motor_speeds(self.slow_speed, -self.normal_speed)  # MAJU dengan kiri lebih lambat: L+, R- (lebih ke kiri)
        
        else:
            # Tidak ada obstacle dekat, eksplorasi ke depan
            # Sesekali buat gerakan random untuk eksplorasi lebih dinamis
            now = time.time()
            if now - self.last_direction_change > 5.0:  # Setiap 5 detik
                self.last_direction_change = now
                # Generate random number untuk pergerakan eksplorasi
                rand_val = np.random.random()
                if rand_val < 0.1:  # 10% chance untuk belok kiri sedikit
                    self.get_logger().debug('Eksplorasi: random belok kiri sedikit')
                    self.set_motor_speeds(self.slow_speed, -self.normal_speed)  # MAJU dengan kiri lebih lambat: L+, R- (lebih ke kiri)
                elif rand_val < 0.2:  # 10% chance untuk belok kanan sedikit
                    self.get_logger().debug('Eksplorasi: random belok kanan sedikit')
                    self.set_motor_speeds(self.normal_speed, -self.slow_speed)  # MAJU dengan kanan lebih lambat: L+, R- (lebih ke kanan)
                else:  # 80% chance untuk maju normal
                    self.get_logger().debug('Eksplorasi: maju normal')
                    self.set_motor_speeds(self.normal_speed, -self.normal_speed)  # MAJU normal: L+, R-
            else:
                # Maju normal
                self.set_motor_speeds(self.normal_speed, -self.normal_speed)  # MAJU normal: L+, R-
    
    def dynamic_window_approach(self):
        """Implementasi algoritma Dynamic Window Approach untuk navigasi"""
        # Implementasi DWA untuk navigasi yang lebih halus
        # Metode ini dipanggil jika navigation_strategy diset ke 'dynamic_window'
        pass  # Untuk implementasi lebih lanjut

def main(args=None):
    rclpy.init(args=args)
    node = RobotAutonomousNavigation()
    
    try:
        rclpy.spin(node)
    except Exception as e:
        node.get_logger().error(f'Error dalam eksekusi: {e}')
    finally:
        # Pastikan motor berhenti sebelum shutdown
        node.led.off()  # Matikan LED saat shutdown
        node.stop_motors()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
