import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Float32
from geometry_msgs.msg import Twist
import time
import os
import signal
import sys
import math
import random

# Import motor control library
try:
    from gamepad_robot_controller.ddsm115 import MotorControl
except ImportError:
    print("Warning: ddsm115 module not found. Running in simulation mode.")
    MotorControl = None

class LidarAutonomousRobot(Node):
    def __init__(self):
        super().__init__('lidar_autonomous_robot')
        
        # === Motor Controller Parameters ===
        self.declare_parameter('r_wheel_port', '/dev/ttyRS485-1')
        self.declare_parameter('l_wheel_port', '/dev/ttyRS485-2')
        self.declare_parameter('update_rate', 30.0)  # Hz
        
        self.r_wheel_port = self.get_parameter('r_wheel_port').value
        self.l_wheel_port = self.get_parameter('l_wheel_port').value
        self.update_rate = self.get_parameter('update_rate').value
        
        # === Object Avoidance Parameters ===
        self.declare_parameter('min_safe_distance', 0.3)  # 50cm
        self.declare_parameter('warning_distance', 0.3)   # 1m
        self.declare_parameter('sector_count', 5)         # Number of sectors to divide LiDAR scan
        self.declare_parameter('direction_change_interval', 5.0)  # seconds
        self.declare_parameter('default_speed', 20)       # Default speed value
        
        self.min_safe_distance = self.get_parameter('min_safe_distance').value
        self.warning_distance = self.get_parameter('warning_distance').value
        self.sector_count = self.get_parameter('sector_count').value
        self.direction_change_interval = self.get_parameter('direction_change_interval').value
        self.default_speed = self.get_parameter('default_speed').value
        
        # Publishers
        self.right_wheel_pub = self.create_publisher(Float32, 'right_wheel_speed', 10)
        self.left_wheel_pub = self.create_publisher(Float32, 'left_wheel_speed', 10)
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        
        # Lidar Subscriber
        self.lidar_subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.lidar_callback,
            10
        )
        
        # Obstacle detection state
        self.obstacle_detected = False
        self.obstacle_directions = [False] * self.sector_count  # [front, front-right, right, back-right, back, back-left, left, front-left]
        self.closest_distance = float('inf')
        self.lidar_data_valid = False
        
        # Movement state
        self.current_direction = 0  # 0: forward, 1: turn right, 2: turn left, 3: backward
        self.stuck_time = 0.0
        self.last_direction_change = time.time()
        
        # Speed settings
        self.speed = self.default_speed
        self.lambat = self.speed / 4
        self.serong = self.speed / 3
        self.stop = 0
        
        self.running = True
        self.current_speed_rwheel = self.stop
        self.current_speed_lwheel = self.stop
        
        # Direct motor control
        self.motor1 = None
        self.motor2 = None
        self.connect_motors()
        
        # Create timers
        self.timer = self.create_timer(1.0/self.update_rate, self.update_callback)
        self.direction_timer = self.create_timer(self.direction_change_interval, self.choose_new_direction)
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
        
        self.get_logger().info("Lidar Autonomous Robot initialized - Running without gamepad")
    
    def signal_handler(self, sig, frame):
        self.get_logger().info(f"Received signal {sig}, shutting down...")
        self.running = False
    
    def verify_port_exists(self, port):
        return os.path.exists(port)
    
    def connect_motors(self):
        if MotorControl is None:
            self.get_logger().warn("Running in simulation mode - no direct motor control")
            return
        
        if self.verify_port_exists(self.r_wheel_port):
            try:
                self.motor1 = MotorControl(device=self.r_wheel_port)
                self.motor1.set_drive_mode(1, 2)
                self.get_logger().info(f"Right motor connected to {self.r_wheel_port}")
            except Exception as e:
                self.get_logger().error(f"Right motor error: {e}")
                self.motor1 = None
        
        if self.verify_port_exists(self.l_wheel_port):
            try:
                self.motor2 = MotorControl(device=self.l_wheel_port)
                self.motor2.set_drive_mode(1, 2)
                self.get_logger().info(f"Left motor connected to {self.l_wheel_port}")
            except Exception as e:
                self.get_logger().error(f"Left motor error: {e}")
                self.motor2 = None
    
    def safe_send_rpm(self, motor_obj, motor_id, speed):
        if not motor_obj:
            return False
        try:
            motor_obj.send_rpm(motor_id, speed)
            return True
        except Exception as e:
            self.get_logger().error(f"Error sending RPM: {e}")
            return False
    
    def lidar_callback(self, msg):
        """Process LiDAR data and detect obstacles"""
        if not self.running:
            return
        
        # Set LiDAR as valid
        self.lidar_data_valid = True
        
        # Find minimum distance
        ranges = list(msg.ranges)
        
        # Remove invalid measurements (often returned as 0.0, inf, or nan)
        filtered_ranges = [r for r in ranges if r > 0.1 and r < 10.0 and not math.isnan(r) and not math.isinf(r)]
        
        if not filtered_ranges:
            self.get_logger().warn("No valid LiDAR readings received")
            self.obstacle_detected = False
            self.closest_distance = float('inf')
            return
        
        # Get min distance from valid readings
        self.closest_distance = min(filtered_ranges)
        
        # Determine if there's an obstacle
        self.obstacle_detected = self.closest_distance < self.warning_distance
        
        # Divide the scan into sectors
        sector_size = len(ranges) // self.sector_count
        self.obstacle_directions = [False] * self.sector_count
        
        for i in range(self.sector_count):
            start_idx = i * sector_size
            end_idx = (i + 1) * sector_size if i < self.sector_count - 1 else len(ranges)
            
            sector_ranges = [r for r in ranges[start_idx:end_idx] 
                            if r > 0.1 and r < 10.0 and not math.isnan(r) and not math.isinf(r)]
            
            if sector_ranges and min(sector_ranges) < self.warning_distance:
                self.obstacle_directions[i] = True
        
        # Log status
        if self.obstacle_detected:
            if self.closest_distance < self.min_safe_distance:
                self.get_logger().warn(f"DANGER: Very close obstacle at {self.closest_distance:.2f}m")
            else:
                self.get_logger().info(f"Obstacle detected at {self.closest_distance:.2f}m")
    
    def publish_wheel_speeds(self):
        if not self.running:
            return
        
        # Publish motor speeds to ROS topics
        right_msg = Float32()
        right_msg.data = float(self.current_speed_rwheel)
        self.right_wheel_pub.publish(right_msg)
        
        left_msg = Float32()
        left_msg.data = float(self.current_speed_lwheel)
        self.left_wheel_pub.publish(left_msg)
        
        # Also publish as cmd_vel for compatibility
        twist_msg = Twist()
        avg_speed = (abs(self.current_speed_rwheel) + abs(self.current_speed_lwheel)) / 2.0
        linear_x = 0.0
        angular_z = 0.0
        
        if self.current_speed_rwheel < 0 and self.current_speed_lwheel > 0:
            # Forward
            linear_x = avg_speed / 100.0  # Scale to m/s
        elif self.current_speed_rwheel > 0 and self.current_speed_lwheel < 0:
            # Backward
            linear_x = -avg_speed / 100.0  # Scale to m/s
        
        if (self.current_speed_rwheel < 0 and self.current_speed_lwheel < 0) or \
           (self.current_speed_rwheel > 0 and self.current_speed_lwheel > 0):
            # Rotation
            angular_z = (self.current_speed_rwheel) / 100.0  # Scale to rad/s
        
        twist_msg.linear.x = linear_x
        twist_msg.angular.z = angular_z
        self.cmd_vel_pub.publish(twist_msg)
    
    def choose_new_direction(self):
        """Choose a new movement direction periodically if not handling obstacles"""
        if not self.running or self.obstacle_detected:
            return
            
        # Save previous direction
        prev_direction = self.current_direction
        
        # Choose a new direction (biased toward forward movement)
        choices = [0, 0, 0, 0, 1, 2, 3]  # Forward has higher probability
        while self.current_direction == prev_direction:
            self.current_direction = random.choice(choices)
            
        direction_names = ["FORWARD", "RIGHT", "LEFT", "BACKWARD"]
        self.get_logger().info(f"Changing direction to {direction_names[self.current_direction]}")
    
    def handle_obstacle_avoidance(self):
        """Determine the best movement to avoid obstacles"""
        if not self.lidar_data_valid:
            # No LiDAR data, continue with current movement
            return self.get_movement_commands()
        
        # Emergency stop if very close obstacle
        if self.closest_distance < self.min_safe_distance:
            self.get_logger().warn(f"Emergency stop: obstacle at {self.closest_distance:.2f}m")
            # Briefly reverse before choosing a new direction
            return self.speed, -self.speed  # Reverse
        
        # If no obstacles, continue with normal movement
        if not self.obstacle_detected:
            # Reset stuck timer
            self.stuck_time = 0.0
            return self.get_movement_commands()
        
        # Obstacle avoidance logic based on sector information
        # Front obstacle (sector 0)
        if self.obstacle_directions[0]:
            # Can't go forward, try to turn
            if not self.obstacle_directions[4]:  # Left is clear
                self.get_logger().info("Obstacle in front, turning left")
                return -self.lambat, -self.lambat  # Turn left
            elif not self.obstacle_directions[1]:  # Right is clear
                self.get_logger().info("Obstacle in front, turning right")
                return self.lambat, self.lambat  # Turn right
            else:
                # Both sides blocked, try to reverse
                self.get_logger().info("Front and sides blocked, reversing")
                return self.speed, -self.speed  # Reverse
        
        # Right obstacle (sector 1)
        elif self.obstacle_directions[1] and self.current_direction == 1:
            # Obstacle on right and trying to turn right, turn left instead
            self.get_logger().info("Obstacle on right, turning left instead")
            return -self.lambat, -self.lambat  # Turn left
        
        # Left obstacle (sector 4)
        elif self.obstacle_directions[4] and self.current_direction == 2:
            # Obstacle on left and trying to turn left, turn right instead
            self.get_logger().info("Obstacle on left, turning right instead")
            return self.lambat, self.lambat  # Turn right
        
        # Default: continue with planned movement
        return self.get_movement_commands()
    
    def get_movement_commands(self):
        """Generate wheel commands based on current direction"""
        rwheel = self.stop
        lwheel = self.stop
        
        if self.current_direction == 0:  # Forward
            rwheel = -self.speed
            lwheel = self.speed
        elif self.current_direction == 1:  # Turn right
            rwheel = self.lambat
            lwheel = self.lambat 
        elif self.current_direction == 2:  # Turn left
            rwheel = -self.lambat
            lwheel = -self.lambat
        elif self.current_direction == 3:  # Backward
            rwheel = self.speed
            lwheel = -self.speed
        
        return rwheel, lwheel
    
    def check_stuck_condition(self):
        """Check if robot is stuck and force a direction change if needed"""
        now = time.time()
        
        # If we've been avoiding the same obstacle for too long, force a change
        if self.obstacle_detected and now - self.last_direction_change > 5.0:
            self.stuck_time += 1.0/self.update_rate
            
            if self.stuck_time > 3.0:  # Stuck for 3 seconds
                # Force a random direction change
                self.current_direction = random.randint(0, 3)
                self.last_direction_change = now
                self.stuck_time = 0.0
                self.get_logger().warn(f"Robot appears stuck! Forcing new direction: {self.current_direction}")
                return True
        else:
            self.stuck_time = 0.0
        
        return False
    
    def update_callback(self):
        if not self.running:
            return
        
        try:
            # Check for stuck condition
            self.check_stuck_condition()
            
            # Get wheel commands based on obstacle avoidance
            self.current_speed_rwheel, self.current_speed_lwheel = self.handle_obstacle_avoidance()
            
            # Publish to ROS 2 topics
            self.publish_wheel_speeds()
            
            # Also send direct commands if motors are connected
            self.safe_send_rpm(self.motor1, 1, self.current_speed_rwheel)
            self.safe_send_rpm(self.motor2, 1, self.current_speed_lwheel)
            
        except Exception as e:
            self.get_logger().error(f"Update error: {e}")
    
    def cleanup(self):
        self.get_logger().info("Cleaning up and stopping motors...")
        
        try:
            self.running = False
            
            if self.motor1:
                try:
                    self.motor1.send_rpm(1, 0)
                    self.motor1.close()
                except Exception as e:
                    self.get_logger().error(f"Error closing motor1: {e}")
            
            if self.motor2:
                try:
                    self.motor2.send_rpm(1, 0)
                    self.motor2.close()
                except Exception as e:
                    self.get_logger().error(f"Error closing motor2: {e}")
            
        except Exception as e:
            self.get_logger().error(f"Error during cleanup: {e}")


def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = LidarAutonomousRobot()
        
        if node.running:
            try:
                rclpy.spin(node)
            except KeyboardInterrupt:
                pass
            finally:
                node.cleanup()
        
        node.destroy_node()
        
    except Exception as e:
        if rclpy.ok():
            print(f"Error in main: {e}")
    finally:
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
