import serial
import math
import time

port = "/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0"
baudrate = 115200
timeout = 1

# Fungsi Koreksi Bias
def correct_bias(raw_distance, bias):
    return raw_distance - bias

# Fungsi untuk menghitung panjang sisi menggunakan hukum kosinus
def A1toA0(a, b, c):
    """
    Fungsi untuk menghitung panjang sisi menggunakan hukum kosinus
    a: panjang sisi pertama
    b: panjang sisi kedua
    sudut: sudut antara sisi a dan b dalam derajat
    """
    # Menghitung sudut Alpha dalam radian
    # Alpha = math.acos(a / b)

    # Menghitung sudut Beta dalam radian (dengan pengurangan 60 derajat, dalam radian)
    Beta = math.atan2(c, b) 

    # Menghitung panjang sisi d menggunakan hukum kosinus
    d = math.sqrt(b**2 + c**2 - (2 * b * c) * math.cos(Beta))
    
    return d, Beta

# Fungsi untuk menghitung sudut robot
def calculate_angle(b, d, Beta):

    z = math.asin( (b / d) * math.sin(Beta) )

    z_degrees = math.degrees(z)

    return z_degrees

try:
    ser = serial.Serial(port, baudrate, timeout=timeout)
    print(f"Connected to {port} at {baudrate} baud.")

    while True:
        if ser.in_waiting > 0:
            data = ser.readline().decode("utf-8").strip()
            if data.startswith("$KT0"):
                try:
                    parts = data.split(",")
                    if len(parts) >= 4:
                        # Parsing Data Jarak
                        raw_values = parts[1:4]
                        processed_values = []
                        for i, value in enumerate(raw_values):
                            if value.lower() == "null":
                                processed_values.append(0.0)
                            else:
                                processed_values.append(float(value))
                        A0, A1, A2 = processed_values

                        # Koreksi bias
                        cal_A0 = correct_bias(A0*100, 15) #b
                        cal_A1 = correct_bias(A1*100, -9) #c
                        cal_A2 = correct_bias(A2*100, -18) #a

                        # Hitung jarak A0 ke A1 dan A0 ke A2 menggunakan hukum kosinus
                        A1keA0, Beta = A1toA0(cal_A2, cal_A0, cal_A1)

                        print(math.degrees(Beta))

                        # Hitung sudut relatif A0 terhadap A1 dan A2 secara real-time
                        angle_robot = calculate_angle(cal_A0, A1keA0, Beta)  # Sudut A1 ke A0

                        print(
                            f"\nA0 = {cal_A0:.2f} cm | A1 = {cal_A1:.2f} cm | A2 = {cal_A2:.2f} cm"
                        )
                        print(
                            f"A1 to A0 = {A1keA0:.2f} cm"
                        )
                        print(f"Angle Robot: {angle_robot:.2f} derajat")
                    else:
                        print("Error: Data tidak lengkap.")
                except ValueError as e:
                    print(f"Error processing data: {e}")

                time.sleep(1)

except serial.SerialException as e:
    print(f"Error: {e}")
except KeyboardInterrupt:
    print("Exiting program.")
finally:
    if "ser" in locals() and ser.is_open:
        ser.close()
        print("Serial connection closed.")
