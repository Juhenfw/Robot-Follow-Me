import numpy as np
import matplotlib.pyplot as plt

# Coordinates for A1, A2, A0 (these are fixed in the 2D plane)
A1 = np.array([0, 0])   # Anchor 1 (part of robot)
A2 = np.array([10, 0])  # Anchor 2 (part of robot)
A0 = np.array([5, 5])   # Target (A0), this is the moving point (target)

# Robot initial position (T0)
T0 = np.array([2, 2])

# Function for calculating distance
def calculate_distance(p1, p2):
    return np.linalg.norm(p1 - p2)

# Trilateration to estimate the robot's position (T0) based on distances to A0, A1, and A2
def trilateration(d1, d2, d3):
    # Coordinates of A0, A1, A2 (A0 is the moving target)
    x0, y0 = A0
    x1, y1 = A1
    x2, y2 = A2

    # Using trilateration to solve for T0 (robot's position) using distance formulas
    # Equation 1: (x - x1)^2 + (y - y1)^2 = d1^2
    # Equation 2: (x - x2)^2 + (y - y2)^2 = d2^2
    # Equation 3: (x - x0)^2 + (y - y0)^2 = d3^2
    
    # Rearrange for X, Y (we use numerical solver to get solution)
    # (x - x1)^2 + (y - y1)^2 = d1^2
    # (x - x2)^2 + (y - y2)^2 = d2^2
    # (x - x0)^2 + (y - y0)^2 = d3^2
    
    # These are nonlinear equations, so we solve them using a numerical method.
    
    def equations(vars):
        x, y = vars
        eq1 = (x - x1)**2 + (y - y1)**2 - d1**2
        eq2 = (x - x2)**2 + (y - y2)**2 - d2**2
        eq3 = (x - x0)**2 + (y - y0)**2 - d3**2
        return [eq1, eq2, eq3]
    
    from scipy.optimize import fsolve
    # Initial guess (close to the average of A0, A1, A2)
    initial_guess = [(x1 + x2 + x0) / 3, (y1 + y2 + y0) / 3]
    
    # Solve the system of nonlinear equations
    result = fsolve(equations, initial_guess)
    return np.array(result)

# Function to compute the error and control signals using PID
def pid_control(target_position, current_position, previous_error, integral):
    # Calculate the error (distance to target)
    error = np.linalg.norm(target_position - current_position)

    # Proportional term
    p_term = error

    # Integral term
    integral += error

    # Derivative term
    d_term = error - previous_error

    # Calculate total control signal
    control_signal = p_term + integral + d_term

    return control_signal, integral, error

# Function to simulate the movement of the robot
def move_robot():
    global T0, A0, previous_error, integral
    positions = [T0.copy()]
    for _ in range(100):  # Simulate 100 time steps
        # Get distances from A0 to T0, A1, and A2
        d1 = calculate_distance(A0, T0)  # Distance from A0 to T0
        d2 = calculate_distance(A0, A1)  # Distance from A0 to A1
        d3 = calculate_distance(A0, A2)  # Distance from A0 to A2
        
        # Trilaterate to estimate position (T0) based on distances
        estimated_position = trilateration(d1, d2, d3)
        
        # Get the control signal using PID control
        control_signal, integral, previous_error = pid_control(A0, T0, previous_error, integral)
        
        # Move the robot toward the target A0
        direction = A0 - T0
        direction = direction / np.linalg.norm(direction)  # Normalize direction
        T0 += direction * control_signal  # Move robot in the direction of A0

        # Store the robot's new position
        positions.append(T0.copy())

    return np.array(positions)

# Run the simulation
robot_path = move_robot()

# Plot the path of the robot
plt.figure(figsize=(8, 6))
plt.plot(robot_path[:, 0], robot_path[:, 1], label="Robot Path", color="blue")
plt.scatter(A0[0], A0[1], color='red', label="Target (A0)", zorder=5)
plt.scatter(A1[0], A1[1], color='green', label="Anchor A1")
plt.scatter(A2[0], A2[1], color='green', label="Anchor A2")
plt.scatter(robot_path[-1, 0], robot_path[-1, 1], color='yellow', label="Final Position (T0)")
plt.legend()
plt.title("Robot Path Following Target (A0) Using UWB Sensors")
plt.xlabel("X Position")
plt.ylabel("Y Position")
plt.grid(True)
plt.show()
