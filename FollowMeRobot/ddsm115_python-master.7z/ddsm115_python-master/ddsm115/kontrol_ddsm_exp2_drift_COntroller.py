import pygame
import time
import ddsm115 as motor

# Konfigurasi port serial
r_wheel = "/dev/serial/by-id/usb-FTDI_FT232R_USB_UART_B0049TUZ-if00-port0"
l_wheel = "/dev/serial/by-id/usb-FTDI_FT232R_USB_UART_B0045S9B-if00-port0"

# Inisialisasi Pygame
pygame.init()
screen = pygame.display.set_mode((400, 300))  # Ukuran layar
pygame.display.set_caption("Kontrol Robot DDSM115 - Drift Mode")
clock = pygame.time.Clock()

# Inisialisasi motor
motor1 = motor.MotorControl(device=r_wheel)
motor1.set_drive_mode(1, 2)

motor2 = motor.MotorControl(device=l_wheel)
motor2.set_drive_mode(1, 2)

# Kecepatan motor
speed = 75  # Kecepatan Normal
lambat = speed / 6  # Kecepatan Rotasi Pelan
serong = speed / 4  # Kecepatan Belok Normal
drift_boost = speed * 1.3  # Kecepatan Drift
stop = 0

running = True
current_speed_rwheel = stop
current_speed_lwheel = stop

# Loop utama
while running:
    screen.fill((0, 0, 0))  # Bersihkan layar
    pygame.display.flip()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()  # Cek tombol yang ditekan
    drifting = keys[pygame.K_LSHIFT]  # Drift mode aktif jika SHIFT ditekan

    # ======== Kombinasi Tombol untuk Belok & Drift ========
    if keys[pygame.K_w] and keys[pygame.K_a]:  # Maju + Belok Kiri
        if drifting:  # Mode Drift
            current_speed_rwheel = -drift_boost
            current_speed_lwheel = serong
        else:  # Mode Normal
            current_speed_rwheel = -speed
            current_speed_lwheel = serong
    elif keys[pygame.K_w] and keys[pygame.K_d]:  # Maju + Belok Kanan
        if drifting:
            current_speed_rwheel = -serong
            current_speed_lwheel = -drift_boost
        else:
            current_speed_rwheel = -serong
            current_speed_lwheel = speed
    elif keys[pygame.K_s] and keys[pygame.K_a]:  # Mundur + Belok Kiri
        if drifting:
            current_speed_rwheel = speed
            current_speed_lwheel = -drift_boost
        else:
            current_speed_rwheel = speed
            current_speed_lwheel = -serong
    elif keys[pygame.K_s] and keys[pygame.K_d]:  # Mundur + Belok Kanan
        if drifting:
            current_speed_rwheel = drift_boost
            current_speed_lwheel = -speed
        else:
            current_speed_rwheel = serong
            current_speed_lwheel = -speed

    # ======== Kontrol Gerakan Normal ========
    elif keys[pygame.K_w]:  # Maju
        current_speed_rwheel = -speed
        current_speed_lwheel = speed
    elif keys[pygame.K_s]:  # Mundur
        current_speed_rwheel = speed
        current_speed_lwheel = -speed
    elif keys[pygame.K_a]:  # Rotasi kiri
        current_speed_rwheel = -lambat
        current_speed_lwheel = -lambat
    elif keys[pygame.K_d]:  # Rotasi kanan
        current_speed_rwheel = lambat
        current_speed_lwheel = lambat
    elif keys[pygame.K_SPACE]:  # ROTASI CEPAT
        current_speed_rwheel = -speed
        current_speed_lwheel = -speed
    elif keys[pygame.K_p]:  # Keluar
        running = False
    else:
        current_speed_rwheel = stop
        current_speed_lwheel = stop

    # Kirim perintah ke motor
    motor1.send_rpm(1, current_speed_rwheel)
    motor2.send_rpm(1, current_speed_lwheel)

    clock.tick(30)  # Batasi ke 30 FPS

# Tutup motor dan keluar dari Pygame
motor1.close()
motor2.close()
pygame.quit()
