import gpiozero

led = gpiozero.LED(17)
led.on()
