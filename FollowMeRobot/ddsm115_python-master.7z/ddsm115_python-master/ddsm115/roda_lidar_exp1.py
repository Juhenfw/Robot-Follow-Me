import numpy as np
from rplidar import RPLidar, RPLidarException
import time
import os
import ddsm115 as motor

# ======== KONFIGURASI ==========
PORT_NAME_LIDAR = "/dev/robot_lidar"
PORT_RIGHT_MOTOR = "/dev/robot_rwheel"
PORT_LEFT_MOTOR = "/dev/robot_lwheel"
BAUDRATE_LIDAR = 256000

LIDAR_DISTANCE_THRESHOLD = 800  # mm
AVOIDANCE_TURN_DURATION = 0.5   # detik
FORWARD_SPEED = 300

# ======== KELAS ROBOT ==========
class Robot:
    def __init__(self):
        # Setup motor
        self.r_motor = None
        self.l_motor = None
        self.setup_motors()

        # Setup LiDAR
        self.lidar = None
        self.running = True
        self.setup_lidar()

    def setup_motors(self):
        if os.path.exists(PORT_RIGHT_MOTOR):
            self.r_motor = motor.MotorControl(device=PORT_RIGHT_MOTOR)
            self.r_motor.set_drive_mode(1, 2)
            print("Motor kanan terhubung")

        if os.path.exists(PORT_LEFT_MOTOR):
            self.l_motor = motor.MotorControl(device=PORT_LEFT_MOTOR)
            self.l_motor.set_drive_mode(1, 2)
            print("Motor kiri terhubung")

    def setup_lidar(self):
        try:
            print("Menginisialisasi LiDAR...")
            self.lidar = RPLidar(PORT_NAME_LIDAR, baudrate=BAUDRATE_LIDAR)

            time.sleep(2)
            self.lidar.stop()              # pastikan LiDAR berhenti
            self.lidar.stop_motor()        # matikan motor lidar dulu
            time.sleep(1)
            self.lidar.start_motor()       # hidupkan motor lidar
            time.sleep(1)
            self.lidar.clear_input()       # bersihkan buffer
            info = self.lidar.get_info()   # test komunikasi
            print("LiDAR terhubung:", info)
        except RPLidarException as e:
            print("Gagal inisialisasi LiDAR:", e)
            self.stop()

    def send_rpm(self, right, left):
        if self.r_motor:
            self.r_motor.send_rpm(1, right)
        if self.l_motor:
            self.l_motor.send_rpm(1, left)

    def stop(self):
        print("Robot berhenti.")
        self.send_rpm(0, 0)
        try:
            if self.lidar:
                self.lidar.stop()
                self.lidar.stop_motor()
                self.lidar.disconnect()
        except:
            pass
        self.running = False

    def move_forward(self):
        self.send_rpm(-FORWARD_SPEED, FORWARD_SPEED)

    def turn_right(self):
        self.send_rpm(-FORWARD_SPEED, -FORWARD_SPEED)

    def turn_left(self):
        self.send_rpm(FORWARD_SPEED, FORWARD_SPEED)

    def run(self):
        try:
            print("Robot berjalan... Tekan CTRL+C untuk berhenti.")

            # START dulu sebelum iter_scans()
            self.lidar.start()
            time.sleep(1)  # tunggu motor berputar stabil

            while self.running:
                obstacle_detected = False

                for scan in self.lidar.iter_scans(max_buf_meas=300):
                    for _, angle, distance in scan:
                        if 330 <= angle <= 360 or 0 <= angle <= 30:
                            if distance < LIDAR_DISTANCE_THRESHOLD:
                                obstacle_detected = True
                                break
                    break  # hanya satu putaran lidar

                if obstacle_detected:
                    print("Objek di depan! Menghindar...")
                    self.turn_right()
                    time.sleep(AVOIDANCE_TURN_DURATION)
                else:
                    self.move_forward()

        except KeyboardInterrupt:
            self.stop()
        except Exception as e:
            print(f"Error: {e}")
            self.stop()


# ======== EKSEKUSI PROGRAM ==========
if __name__ == "__main__":
    robot = Robot()
    robot.run()
