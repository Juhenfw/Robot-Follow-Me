import numpy as np
from sklearn.cluster import DBSCAN
from filterpy.kalman import KalmanFilter
import matplotlib.pyplot as plt

# Mock LiDAR data (list of [angle_deg, distance_m])
def generate_mock_lidar_data():
    angles = np.linspace(0, 360, 360)
    distances = np.random.normal(2.0, 0.05, size=360)  # Simulate circular wall
    # Add a "person" at 1.5m, 90°
    distances[85:95] = np.random.normal(1.5, 0.05, size=10)
    return np.vstack((angles, distances)).T

# Convert polar to cartesian
def polar_to_cartesian(data):
    angles_rad = np.deg2rad(data[:, 0])
    x = data[:, 1] * np.cos(angles_rad)
    y = data[:, 1] * np.sin(angles_rad)
    return np.column_stack((x, y))

# Find clusters
def find_clusters(cartesian_points, eps=0.15, min_samples=5):
    db = DBSCAN(eps=eps, min_samples=min_samples).fit(cartesian_points)
    labels = db.labels_
    clusters = []
    for label in set(labels):
        if label == -1:
            continue
        cluster_pts = cartesian_points[labels == label]
        centroid = np.mean(cluster_pts, axis=0)
        clusters.append((centroid, cluster_pts))
    return clusters

# Set up Kalman Filter
def create_kalman_filter():
    kf = KalmanFilter(dim_x=4, dim_z=2)
    dt = 1.0
    kf.F = np.array([[1, 0, dt, 0],
                     [0, 1, 0, dt],
                     [0, 0, 1, 0],
                     [0, 0, 0, 1]])
    kf.H = np.array([[1, 0, 0, 0],
                     [0, 1, 0, 0]])
    kf.R *= 0.01
    kf.P *= 10
    kf.Q *= 0.01
    return kf

# Match closest cluster to predicted person
def match_person(clusters, predicted_xy):
    min_dist = float('inf')
    matched = None
    for centroid, _ in clusters:
        dist = np.linalg.norm(centroid - predicted_xy)
        if dist < min_dist:
            min_dist = dist
            matched = centroid
    return matched

# Main loop
kf = create_kalman_filter()
kf.x[:2] = np.array([[0.0], [1.5]])  # initial guess

plt.ion()
fig, ax = plt.subplots()

while True:
    lidar_data = generate_mock_lidar_data()
    cartesian = polar_to_cartesian(lidar_data)
    clusters = find_clusters(cartesian)

    # Predict next position
    kf.predict()
    pred_xy = kf.x[:2].flatten()

    # Match cluster to predicted position
    match = match_person(clusters, pred_xy)
    if match is not None:
        z = np.array(match)
        kf.update(z)

    # Plot
    ax.clear()
    ax.scatter(cartesian[:, 0], cartesian[:, 1], s=1, color='gray', label='LiDAR points')
    for centroid, pts in clusters:
        ax.scatter(*pts.T, s=5, label='Cluster')
        ax.plot(centroid[0], centroid[1], 'ro', label='Centroid')

    # Plot prediction and estimate
    pred = kf.x[:2].flatten()
    ax.plot(pred[0], pred[1], 'bo', label='Kalman Pos')
    ax.set_xlim(-3, 3)
    ax.set_ylim(-3, 3)
    ax.set_aspect('equal')
    ax.legend()
    plt.pause(0.01)
