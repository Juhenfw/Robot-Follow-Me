import curses
import time
import curses.panel
from ddsm115 import MotorControl  # Sesuaikan dengan nama file Anda

def main(stdscr):
    motor = MotorControl()
    motor.set_drive_mode(1, 2)  # Mode kecepatan (velocity)

    speed = 100  # Kecepatan default
    running = True

    stdscr.nodelay(True)  # Jangan tunggu input
    panel = curses.panel.new_panel(stdscr)
    panel.top()
    panel.show()
    curses.doupdate()

    while running:
        key = stdscr.getch()  # Baca input keyboard

        if key == ord('w'):
            stdscr.clear()  # Bersihkan layar sebelum menulis teks baru
            try:
                stdscr.addstr("Maju\n")
            except curses.error:
                pass
            stdscr.refresh()
            motor.send_rpm(1, speed)

        elif key == ord('s'):
            stdscr.clear()
            try:
                stdscr.addstr("Mundur\n")
            except curses.error:
                pass
            stdscr.refresh()
            motor.send_rpm(1, -speed)

        elif key == ord('q'):
            stdscr.clear()
            try:
                stdscr.addstr("Keluar\n")
            except curses.error:
                pass
            stdscr.refresh()
            running = False

        else:
            motor.send_rpm(1, 0)  # Berhenti jika tidak ada input

        time.sleep(0.05)

    motor.close()
    stdscr.clear()
    try:
        stdscr.addstr("Program selesai.\n")
    except curses.error:
        pass
    stdscr.refresh()

if __name__ == "__main__":
    curses.wrapper(main)
