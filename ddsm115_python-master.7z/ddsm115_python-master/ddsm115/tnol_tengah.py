import math

# Fungsi untuk menghitung panjang d atau e menggunakan hukum kosinus
def hitung_jarak(a, b, sudut):
    """
    Fungsi untuk menghitung panjang sisi menggunakan hukum kosinus
    a: panjang sisi pertama
    b: panjang sisi kedua
    sudut: sudut antara sisi a dan b dalam derajat
    """
    # Mengkonversi sudut dari derajat ke radian
    sudut_radian = math.radians(sudut)
    
    # Menghitung panjang sisi menggunakan hukum kosinus
    panjang_sisi = math.sqrt(a**2 + b**2 - 2 * a * b * math.cos(sudut_radian))
    
    return panjang_sisi

# Contoh penggunaan fungsi untuk menghitung panjang d dan e
# Misalnya kita tahu sudut antara sisi a dan b adalah 60 derajat
a = 50  # cm
b = 30  # cm
sudut_ab = 60  # derajat

# Menghitung panjang d
d = hitung_jarak(a, b, sudut_ab)
print(f"Panjang d: {d:.2f} cm")

# Misalnya kita tahu sudut antara sisi b dan c adalah 45 derajat
c = 30  # cm
sudut_bc = 45  # derajat

# Menghitung panjang e
e = hitung_jarak(b, c, sudut_bc)
print(f"Panjang e: {e:.2f} cm")