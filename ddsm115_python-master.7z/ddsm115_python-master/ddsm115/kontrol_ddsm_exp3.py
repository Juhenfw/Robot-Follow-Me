import curses
import time
import curses.panel
import ddsm115 as motor
import threading

wheel1 = "/dev/ttyUSB0"
wheel2 = "/dev/ttyUSB1"

# Fungsi untuk mengontrol motor
def motor_control(motor1, motor2, speed, stop):
    current_speed_motor1 = stop
    current_speed_motor2 = stop
    last_update_time = time.time()
    update_interval = 0.01

    while True:
        if time.time() - last_update_time >= update_interval:
            motor1.send_rpm(1, current_speed_motor1)
            motor2.send_rpm(1, current_speed_motor2)
            last_update_time = time.time()
        time.sleep(0.05)

# Fungsi untuk menangani input tombol
def handle_input(stdscr, motor1, motor2, speed, stop):
    current_speed_motor1 = stop
    current_speed_motor2 = stop
    stdscr.nodelay(True)

    while True:
        key = stdscr.getch()  # Membaca input tombol
        if key == ord('w'):
            key2 = stdscr.getch()

            if key2 == ord('d'):  # Belok kanan
                stdscr.clear()
                try:
                    stdscr.addstr("Belok Kanan\n")
                except curses.error:
                    pass
                stdscr.refresh()
                current_speed_motor1 = speed
                current_speed_motor2 = -speed

            elif key2 == ord('a'):  # Belok kiri
                stdscr.clear()
                try:
                    stdscr.addstr("Belok Kiri\n")
                except curses.error:
                    pass
                stdscr.refresh()
                current_speed_motor1 = -speed
                current_speed_motor2 = speed
            else:
                stdscr.clear() 
                try:
                    stdscr.addstr("Maju\n")
                except curses.error:
                    pass
                stdscr.refresh()
                current_speed_motor1 = speed
                current_speed_motor2 = -speed
 
        elif key == ord('s'):
            stdscr.clear()
            try:
                stdscr.addstr("Mundur\n")
            except curses.error:
                pass
            stdscr.refresh()
            current_speed_motor1 = -speed
            current_speed_motor2 = speed

        elif key == ord('a'):
            stdscr.clear()
            try:
                stdscr.addstr("Kiri\n")
            except curses.error:
                pass
            stdscr.refresh()
            current_speed_motor1 = stop
            current_speed_motor2 = -speed

        elif key == ord('d'):
            stdscr.clear()
            try:
                stdscr.addstr("Kanan\n")
            except curses.error:
                pass
            stdscr.refresh()
            current_speed_motor1 = speed
            current_speed_motor2 = stop

        elif key == ord('q'):
            stdscr.clear()
            try:
                stdscr.addstr("Keluar\n")
            except curses.error:
                pass
            stdscr.refresh()
            break

        else:
            current_speed_motor1 = stop  # Menghentikan motor jika tidak ada tombol yang ditekan
            current_speed_motor2 = stop  # Menghentikan motor jika tidak ada tombol yang ditekan
        
        # Update motor di thread utama
        motor1.send_rpm(1, current_speed_motor1)
        motor2.send_rpm(1, current_speed_motor2)

        time.sleep(0.05)

def main(stdscr):
    motor1 = motor.MotorControl(device=wheel1)
    motor1.set_drive_mode(1, 2)

    motor2 = motor.MotorControl(device=wheel2)
    motor2.set_drive_mode(1, 2)

    speed = 100
    stop = 0
    running = True

    # Thread untuk motor control
    motor_thread = threading.Thread(target=motor_control, args=(motor1, motor2, speed, stop))
    motor_thread.daemon = True  # Agar thread berhenti saat program utama selesai
    motor_thread.start()

    # Thread untuk menangani input
    handle_input(stdscr, motor1, motor2, speed, stop)

    motor1.close()
    motor2.close()
    stdscr.clear()
    try:
        stdscr.addstr("Program selesai.\n")
    except curses.error:
        pass
    stdscr.refresh()

if __name__ == "__main__":
    curses.wrapper(main)
