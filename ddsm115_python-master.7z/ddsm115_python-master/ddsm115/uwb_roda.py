import socket
import time
import ddsm115 as motor
import math

# Setup alamat dan port yang sama dengan program laptop
host = '0.0.0.0'  # Mendengarkan pada semua interface jaringan
port = 12345  # Port yang digunakan oleh laptop

# Setup motor DDSM115 (misalnya melalui RS485)
wheel1 = "/dev/ttyUSB0"
wheel2 = "/dev/ttyUSB1"
motor1 = motor.MotorControl(device=wheel1)
motor2 = motor.MotorControl(device=wheel2)
motor1.set_drive_mode(1, 2)
motor2.set_drive_mode(1, 2)

# Fungsi untuk menghitung tindakan berdasarkan sudut dan jarak
def control_robot(distance, angle):
    speed = 50
    stop = 0

    if distance < 150:
        motor1.send_rpm(1, stop)
        motor2.send_rpm(1, stop)
        print("Robot berhenti")
    elif 0 <= angle < 45:
        motor1.send_rpm(1, speed)
        motor2.send_rpm(1, -speed)
        print("Robot maju")
    elif 45 <= angle < 135:
        motor1.send_rpm(1, stop)
        motor2.send_rpm(1, speed)
        print("Robot belok kiri")
    elif 135 <= angle < 225:
        motor1.send_rpm(1, -speed)
        motor2.send_rpm(1, stop)
        print("Robot belok kanan")
    elif 225 <= angle < 315:
        motor1.send_rpm(1, stop)
        motor2.send_rpm(1, -speed)
        print("Robot mundur")
    else:
        motor1.send_rpm(1, stop)
        motor2.send_rpm(1, stop)
        print("Robot berhenti")

def main():
    # Membuat server socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind((host, port))
        server_socket.listen(1)
        print(f"Listening on {host}:{port}")

        while True:
            # Menerima koneksi dari laptop
            client_socket, client_address = server_socket.accept()
            with client_socket:
                print(f"Connected by {client_address}")
                
                while True:
                    # Menerima data dari laptop
                    data = client_socket.recv(1024)
                    if not data:
                        break
                    
                    # Decode data dan pisahkan menjadi jarak dan sudut
                    data_str = data.decode('utf-8')
                    distance, angle = map(float, data_str.split(" | "))
                    
                    print(f"Received - Distance: {distance} | Angle: {angle}")
                    
                    # Kontrol robot berdasarkan jarak dan sudut
                    control_robot(distance, angle)

if __name__ == "__main__":
    main()