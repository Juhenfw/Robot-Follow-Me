import curses
import time
import curses.panel
import ddsm115 as motor

r_wheel = "/dev/serial/by-id/usb-FTDI_FT232R_USB_UART_B0049TUZ-if00-port0"
l_wheel = "/dev/serial/by-id/usb-FTDI_FT232R_USB_UART_B0045S9B-if00-port0"

def main(stdscr):
    motor1 = motor.MotorControl(device = r_wheel)
    motor1.set_drive_mode(1, 2)

    motor2 = motor.MotorControl(device = l_wheel)                                                                                                                                                                                                                                                                                                                                                                            
    motor2.set_drive_mode(1, 2)

    speed = 300
    lambat = speed/8
    serong = speed/6
    stop = 0
    running = True

    stdscr.nodelay(True)
    panel = curses.panel.new_panel(stdscr)
    panel.top()
    panel.show()
    curses.doupdate()


    last_update_time = time.time()
    update_interval = 0.000001  
    
    current_speed_rwheel = stop
    current_speed_lwheel = stop

    while running:
        key = stdscr.getch() 

        # if key == ord('w') and stdscr.getch() == ord('d'):
        #     stdscr.clear()
        #     try:
        #         stdscr.addstr("Belok Kanan\n")
        #     except curses.error:
        #         pass
        #     stdscr.refresh()
        #     current_speed_rwheel = speed
        #     current_speed_lwheel = -speed
        
        # elif key == ord('w') and stdscr.getch() == ord('a'):
        #     stdscr.clear()
        #     try:
        #         stdscr.addstr("Belok Kiri\n")
        #     except curses.error:
        #         pass
        #     stdscr.refresh()
        #     current_speed_rwheel = -speed
        #     current_speed_lwheel = speed

        if key == ord('q'):
            key2 = stdscr.getch()
            stdscr.clear()
            try:
                stdscr.addstr("Belok Kanan\n")
            except curses.error:
                pass
            stdscr.refresh()
            current_speed_rwheel = -serong
            current_speed_lwheel = lambat
        
        elif key == ord('e'):
            key2 = stdscr.getch()
            stdscr.clear()
            try:
                stdscr.addstr("Belok Kiri\n")
            except curses.error:
                pass
            stdscr.refresh()
            current_speed_rwheel = lambat
            current_speed_lwheel = -serong

        elif key == ord('s'): # Mundur
            key2 = stdscr.getch()
            stdscr.clear()
            try:
                stdscr.addstr("Mundur\n")
            except curses.error:
                pass
            stdscr.refresh()
            current_speed_rwheel = speed
            current_speed_lwheel = -speed

        elif key == ord('w'): # Maju
            key2 = stdscr.getch()
            

            if key2 == ord('d'):  # Belok kanan
                stdscr.clear()
                try:
                    stdscr.addstr("Belok Kanan\n")
                except curses.error:
                    pass
                stdscr.refresh()
                current_speed_rwheel = lambat
                current_speed_lwheel = lambat

            elif key2 == ord('a'):  # Belok kiri
                stdscr.clear()
                try:
                    stdscr.addstr("Belok Kiri\n")
                except curses.error:
                    pass
                stdscr.refresh()
                current_speed_rwheel = -lambat
                current_speed_lwheel = -lambat
            else:
                stdscr.clear() 
                try:
                    stdscr.addstr("Maju\n")
                except curses.error:
                    pass
                stdscr.refresh()
                current_speed_rwheel = -speed
                current_speed_lwheel = speed

        elif key == ord('a'):
            key2 = stdscr.getch()
            stdscr.clear()
            try:
                stdscr.addstr("Kiri\n")
            except curses.error:
                pass
            stdscr.refresh()
            current_speed_rwheel = -lambat
            current_speed_lwheel = -lambat

        elif key == ord('d'):
            key2 = stdscr.getch()
            stdscr.clear()
            try:
                stdscr.addstr("Kanan\n")
            except curses.error:
                pass
            stdscr.refresh()
            current_speed_rwheel = lambat
            current_speed_lwheel = lambat

        elif key == ord('z'):
            stdscr.clear()
            try:
                stdscr.addstr("Keluar\n")
            except curses.error:
                pass
            stdscr.refresh()
            running = False

        else:
            current_speed_rwheel = 0
            current_speed_lwheel = 0

        if time.time() - last_update_time >= update_interval:
            motor1.send_rpm(1, current_speed_rwheel)
            motor2.send_rpm(1, current_speed_lwheel)
            last_update_time = time.time()

        time.sleep(0.0315)

    motor1.close()
    motor2.close()
    stdscr.clear()
    try:
        stdscr.addstr("Program selesai.\n")
    except curses.error:
        pass
    stdscr.refresh()

if __name__ == "__main__":
    curses.wrapper(main)
