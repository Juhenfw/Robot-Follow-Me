import curses
import time
import curses.panel
import ddsm115 as motor

wheel1 = "/dev/ttyUSB0"
wheel2 = "/dev/ttyUSB1"

def main(stdscr):
    motor1 = motor.MotorControl(device = wheel1)
    motor1.set_drive_mode(1, 2)

    motor2 = motor.MotorControl(device = wheel2)                                                                                                                                                                                                                                                                                                                                                                            
    motor2.set_drive_mode(1, 2)

    speed = 50
    stop = 0
    running = True

    stdscr.nodelay(True)
    panel = curses.panel.new_panel(stdscr)
    panel.top()
    panel.show()
    curses.doupdate()

    last_update_time = time.time()
    update_interval = 0.000001  
    
    current_speed_motor1 = 0
    current_speed_motor2 = 0

    while running:
        key = stdscr.getch() 

        if key == ord('w'):
            stdscr.clear() 
            try:
                stdscr.addstr("Maju\n")
            except curses.error:
                pass
            stdscr.refresh()
            current_speed_motor1 = speed
            current_speed_motor2 = -speed

        elif key == ord('s'):
            stdscr.clear()
            try:
                stdscr.addstr("Mundur\n")
            except curses.error:
                pass
            stdscr.refresh()
            current_speed_motor1 = -speed
            current_speed_motor2 = speed

        elif key == ord('a'):
            stdscr.clear()
            try:
                stdscr.addstr("Kiri\n")
            except curses.error:
                pass
            stdscr.refresh()
            current_speed_motor1 = stop
            current_speed_motor2 = speed

        elif key == ord('d'):
            stdscr.clear()
            try:
                stdscr.addstr("Kanan\n")
            except curses.error:
                pass
            stdscr.refresh()
            current_speed_motor1 = -speed
            current_speed_motor2 = stop

        elif key == ord('q'):
            stdscr.clear()
            try:
                stdscr.addstr("Keluar\n")
            except curses.error:
                pass
            stdscr.refresh()
            running = False

        else:
            current_speed_motor1 = 0
            current_speed_motor2 = 0

        if time.time() - last_update_time >= update_interval:
            motor1.send_rpm(1, current_speed_motor1)
            motor2.send_rpm(1, current_speed_motor2)
            last_update_time = time.time()

        time.sleep(0.0315)

    motor1.close()
    motor2.close()
    stdscr.clear()
    try:
        stdscr.addstr("Program selesai.\n")
    except curses.error:
        pass
    stdscr.refresh()

if __name__ == "__main__":
    curses.wrapper(main)
