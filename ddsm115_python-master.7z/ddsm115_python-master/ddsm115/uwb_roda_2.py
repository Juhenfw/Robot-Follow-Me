import curses
import time
import math
import serial
import curses.panel
import ddsm115 as motor

# Konfigurasi USB Port untuk Motor dan Sensor UWB
wheel1 = "/dev/ttyUSB3"   # Port untuk motor kiri

wheel2 = "/dev/ttyUSB4"   # Port untuk motor kanan
uwb_port = "/dev/ttyUSB0" # Port untuk sensor UWB

# Fungsi Koreksi Bias (Jika ada kesalahan jarak akibat posisi UWB)
def correct_bias(raw_distance, bias):
    return raw_distance - bias

# Fungsi Menghitung Panjang Sisi Segitiga (Hukum Cosinus) 
def sisi_segitiga(a, b, sudut):
    sudut_radian = math.radians(sudut)
    panjang_sisi = math.sqrt(a**2 + b**2 - 2 * a * b * math.cos(sudut_radian))
    return panjang_sisi

# Fungsi Utama
def main(stdscr):
    # Inisialisasi Motor
    motor_kiri = motor.MotorControl(device=wheel1)
    motor_kiri.set_drive_mode(1, 2)

    motor_kanan = motor.MotorControl(device=wheel2)
    motor_kanan.set_drive_mode(1, 2)

    # Konfigurasi Awal
    speed = 50
    stop = 0
    running = True

    # Inisialisasi Tampilan
    stdscr.nodelay(True)
    panel = curses.panel.new_panel(stdscr)
    panel.top()
    panel.show()
    curses.doupdate()

    # Inisialisasi Sensor UWB
    try:
        uwb = serial.Serial(uwb_port, 115200, timeout=1)
        print(f"Connected to UWB at {uwb_port}")
    except serial.SerialException as e:
        print(f"Error connecting to UWB: {e}")
        return

    # Timer untuk Update Motor
    last_update_time = time.time()
    update_interval = 0.1  # Update setiap 0.1 detik

    # Variabel kecepatan motor
    current_speed_motor_kiri = 0
    current_speed_motor_kanan = 0

    # Loop Utama
    while running:
        key = stdscr.getch()

        # Baca Data dari Sensor UWB
        if uwb.in_waiting > 0:
            data = uwb.readline().decode("utf-8").strip()
            if data.startswith("$KT0"):
                try:
                    parts = data.split(",")
                    if len(parts) >= 4:
                        # Parsing Data Jarak
                        raw_values = parts[1:4]
                        processed_values = []
                        for i, value in enumerate(raw_values):
                            if value.lower() == "null":
                                processed_values.append(0.0)
                            else:
                                processed_values.append(float(value))

                        # Jarak A0, A1, A2 dalam cm
                        A0, A1, A2 = processed_values
                        cal_A0 = correct_bias(A0 * 100, 100)  # Bias A0
                        cal_A1 = correct_bias(A1 * 100, 0)   # Bias A1
                        cal_A2 = correct_bias(A2 * 100, 0)   # Bias A2

                        # Hitung jarak antara A0 ke A1 dan A2
                        A0_A1 = sisi_segitiga(cal_A0, cal_A1, 150)
                        A0_A2 = sisi_segitiga(cal_A0, cal_A2, 150)

                        # Tampilkan Jarak di Terminal
                        stdscr.clear()
                        try:
                            stdscr.addstr(f"A0 ke T0: {cal_A0:.2f} cm\n")
                            stdscr.addstr(f"A0 ke A1: {A0_A1:.2f} cm | A0 ke A2: {A0_A2:.2f} cm\n")
                        except curses.error:
                            pass
                        stdscr.refresh()

                        # Kontrol Motor Berdasarkan Jarak
                        if (cal_A0 > 70 and cal_A0 < (A0_A1 or A0_A2)): #lurus
                            current_speed_motor_kiri = speed
                            current_speed_motor_kanan = speed
                        elif (A0_A1 > cal_A0 > A0_A2): #belok kanan
                            current_speed_motor_kiri = speed
                            current_speed_motor_kanan = stop
                        elif (A0_A2 > cal_A0 > A0_A1): #belok kiri
                            current_speed_motor_kiri = stop
                            current_speed_motor_kanan = speed
                        # elif (A0_A2 > 70): #rotasi
                        #     current_speed_motor_kiri = speed
                        #     current_speed_motor_kanan = stop
                        else:
                            current_speed_motor_kiri = stop
                            current_speed_motor_kanan = stop

                except ValueError as e:
                    print(f"Error processing UWB data: {e}")

        # Keluar dari Program dengan Tombol 'q'
        if key == ord('q'):
            running = False

        # Update Kecepatan Motor (Hanya Jika Ada Perubahan)
        if time.time() - last_update_time >= update_interval:
            motor_kiri.send_rpm(1, current_speed_motor_kiri)
            motor_kanan.send_rpm(1, current_speed_motor_kanan)
            last_update_time = time.time()

        time.sleep(0.03)  # Batasi Kecepatan Loop

    # Bersihkan dan Tutup Motor
    motor_kiri.close()
    motor_kanan.close()
    uwb.close()
    stdscr.clear()
    try:
        stdscr.addstr("Program selesai.\n")
    except curses.error:
        pass
    stdscr.refresh()

if __name__ == "__main__":
    curses.wrapper(main)
