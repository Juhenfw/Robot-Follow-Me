import curses
import time
import math
import serial
import curses.panel
import ddsm115 as motor

# Konfigurasi port serial
r_wheel = "/dev/serial/by-id/usb-FTDI_FT232R_USB_UART_B0049TUZ-if00-port0"
l_wheel = "/dev/serial/by-id/usb-FTDI_FT232R_USB_UART_B0045S9B-if00-port0"
uwb_port = "/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0"

# Posisi Anchor dalam cm (Relatif terhadap robot)
A1_POSITION = (-20, 0)  # Kiri belakang robot
A2_POSITION = (20, 0)   # Kanan belakang robot

# Fungsi Koreksi Bias
def correct_bias(raw_distance, bias):
    return raw_distance - bias

# Fungsi Menghitung Posisi A0 menggunakan Trilaterasi
def trilaterate(d0, d1, d2):
    """
    Menghitung posisi A0 berdasarkan trilaterasi menggunakan A1 dan A2.
    d0: Jarak ke A0 (cm)
    d1: Jarak ke A1 (cm)
    d2: Jarak ke A2 (cm)
    """
    x1, y1 = A1_POSITION
    x2, y2 = A2_POSITION

    # Hitung koordinat A0 relatif terhadap robot
    x = (d1**2 - d2**2 + x2**2 - x1**2) / (2 * (x2 - x1))
    y = math.sqrt(abs(d1**2 - x**2))

    return x, y

# Fungsi Menghitung Sudut A0 terhadap Robot
def calculate_angle(x, y):
    """
    Menghitung sudut A0 terhadap robot dalam derajat.
    0° = Lurus ke depan, +90° = Kiri, -90° atau 270° = Kanan, ±180° = Belakang
    """
    angle = math.degrees(math.atan2(y, x))
    if angle < 0:
        angle += 360  # Normalisasi sudut agar tetap dalam rentang 0°–360°
    return angle

# Fungsi Utama
def main(stdscr):
    # Inisialisasi Motor
    motor_kanan = motor.MotorControl(device=r_wheel)
    motor_kanan.set_drive_mode(1, 2)

    motor_kiri = motor.MotorControl(device=l_wheel)
    motor_kiri.set_drive_mode(1, 2)

    # Konfigurasi Awal
    speed = 50
    rotate_speed = 30  # Kecepatan rotasi lebih lambat dari maju
    stop = 0
    running = True

    # Inisialisasi Tampilan
    stdscr.nodelay(True)
    panel = curses.panel.new_panel(stdscr)
    panel.top()
    panel.show()
    curses.doupdate()

    # Inisialisasi Sensor UWB
    try:
        uwb = serial.Serial(uwb_port, 115200, timeout=1)
        print(f"Connected to UWB at {uwb_port}")
    except serial.SerialException as e:
        print(f"Error connecting to UWB: {e}")
        return

    # Timer untuk Update Motor
    last_update_time = time.time()
    update_interval = 0.1  # Update setiap 0.1 detik

    # Variabel kecepatan motor
    current_speed_motor_kanan = 0
    current_speed_motor_kiri = 0
    movement_status = "Berhenti"

    # Loop Utama
    while running:
        key = stdscr.getch()

        # Baca Data dari Sensor UWB
        if uwb.in_waiting > 0:
            data = uwb.readline().decode("utf-8").strip()
            if data.startswith("$KT0"):
                try:
                    parts = data.split(",")
                    if len(parts) >= 4:
                        # Parsing Data Jarak
                        raw_values = parts[1:4]
                        processed_values = []
                        for value in raw_values:
                            if value.lower() == "null":
                                processed_values.append(0.0)
                            else:
                                processed_values.append(float(value))

                        # Jarak A0, A1, A2 dalam cm
                        A0, A1, A2 = processed_values
                        cal_A0 = correct_bias(A0 * 100, 100)  # Bias A0
                        cal_A1 = correct_bias(A1 * 100, 0)   # Bias A1
                        cal_A2 = correct_bias(A2 * 100, 0)   # Bias A2

                        # Hitung Posisi A0
                        x, y = trilaterate(cal_A0, cal_A1, cal_A2)
                        angle = calculate_angle(x, y)

                        # ======== LOGIKA KONTROL ROBOT ========

                        # Jika T0 ke A0 < 50 cm, robot berhenti
                        if cal_A0 < 50:
                            current_speed_motor_kanan = stop
                            current_speed_motor_kiri = stop
                            movement_status = "Berhenti (Terlalu Dekat)"
                        
                        # Jika masih di atas 50 cm, lanjutkan kontrol berdasarkan sudut
                        else:
                            if 345 <= angle or angle <= 15:  # Lurus ke depan (0° ±15°)
                                current_speed_motor_kanan = -speed
                                current_speed_motor_kiri = speed
                                movement_status = "Maju"
                            elif 15 < angle <= 90:  # Belok kiri (antara 15°–90°)
                                current_speed_motor_kanan = speed
                                current_speed_motor_kiri = stop
                                movement_status = "Belok Kiri"
                            elif 270 <= angle < 345:  # Belok kanan (antara 270°–345°)
                                current_speed_motor_kanan = stop
                                current_speed_motor_kiri = speed
                                movement_status = "Belok Kanan"
                            elif 90 < angle < 270:  # Jika A0 di belakang, lakukan rotasi
                                if angle > 180:  # Rotasi kanan jika sudut lebih besar dari 180°
                                    current_speed_motor_kanan = -rotate_speed
                                    current_speed_motor_kiri = rotate_speed
                                    movement_status = "Rotasi Kanan"
                                else:  # Rotasi kiri jika sudut kurang dari 180°
                                    current_speed_motor_kanan = rotate_speed
                                    current_speed_motor_kiri = -rotate_speed
                                    movement_status = "Rotasi Kiri"
                            else:
                                current_speed_motor_kanan = stop
                                current_speed_motor_kiri = stop
                                movement_status = "Berhenti"

                        # ======== MENAMPILKAN DATA DI TERMINAL ========
                        stdscr.clear()
                        try:
                            stdscr.addstr(f"STATUS: {movement_status}\n")
                            stdscr.addstr(f"A0 ke T0: {cal_A0:.2f} cm\n")
                            stdscr.addstr(f"Posisi A0: x={x:.2f} cm, y={y:.2f} cm\n")
                            stdscr.addstr(f"Sudut ke A0: {angle:.2f}°\n")
                        except curses.error:
                            pass
                        stdscr.refresh()

                except ValueError as e:
                    print(f"Error processing UWB data: {e}")

        if key == ord('q'):
            running = False

        if time.time() - last_update_time >= update_interval:
            motor_kanan.send_rpm(1, current_speed_motor_kanan)
            motor_kiri.send_rpm(1, current_speed_motor_kiri)
            last_update_time = time.time()

        time.sleep(0.03)

    motor_kanan.close()
    motor_kiri.close()
    uwb.close()

if __name__ == "__main__":
    curses.wrapper(main)
