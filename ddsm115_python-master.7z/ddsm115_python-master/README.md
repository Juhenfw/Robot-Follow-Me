# DDSM115 

This is a python module to easily connect with DDSM115 direct drive small brushless motor.

## Install

- `sudo pip3 install crcmod`
- `sudo python3 setup.py install`
